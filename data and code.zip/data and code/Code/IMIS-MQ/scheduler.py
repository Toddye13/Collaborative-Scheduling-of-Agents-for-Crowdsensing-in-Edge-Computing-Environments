import csv
import math
import copy
from collections import defaultdict
from incremental_mis import IncrementalMIS


class DroneWorkerScheduler:
    """无人机-工人调度器"""

    def __init__(self, drone_file="uavMap.csv", worker_file="workerMap.csv",
                 task_file="taskMap.csv", dc_file="datacenterMap.csv", time_steps=6):
        """初始化调度器"""
        self.mis_solver = None
        self.positions = {
            'drones': {},
            'workers': {},
            'tasks': {},
            'data_centers': {}
        }
        self.drone_capacity = {}
        self.worker_info = {}
        self.task_data = {}
        self.entity_queues = {'drone': defaultdict(list), 'worker': defaultdict(list)}
        self.mobility_radii = {
            'drones': {},
            'workers': {}
        }
        self.time_steps = time_steps
        self.simulation_results = []
        self.data_offloaded = 0
        self.current_time_step = 0

        # 实体移动状态跟踪
        self.moving_entities = {
            'drones': {},
            'workers': {}
        }

        # 添加移动历史记录
        self.movement_history = {
            'drones': {},
            'workers': {}
        }

        # 新添加的状态跟踪
        self.newly_arrived_entities = set()
        self.collaboration_waiting = {'drones': set(), 'workers': set()}
        self.collaboration_status = {}

        # 任务分配状态跟踪
        self.task_assignment = {}

        # 从CSV文件加载数据
        self._load_from_csv(drone_file, worker_file, task_file, dc_file)

        # 初始化状态跟踪
        self.worker_availability = {}
        for worker_id in self.positions['workers']:
            self.worker_availability[worker_id] = True
            self.movement_history['workers'][worker_id] = []

        # 初始化任务状态
        self.task_status = {task_id: '未完成' for task_id in self.positions['tasks']}

        # 记录初始位置
        for drone_id, pos in self.positions['drones'].items():
            self.movement_history['drones'][drone_id] = []
            self.movement_history['drones'][drone_id].append((0, "初始位置", pos))
        for worker_id, pos in self.positions['workers'].items():
            self.movement_history['workers'][worker_id].append((0, "初始位置", pos))

    def _load_from_csv(self, drone_file, worker_file, task_file, dc_file):
        """从CSV文件加载数据"""
        # 加载无人机数据
        with open(drone_file, 'r') as f_drone:
            reader_drone = csv.DictReader(f_drone)
            for row in reader_drone:
                drone_id = row['ID']
                position_str = row['x,y'].split(',') if 'x,y' in row else [row['x'], row['y']]
                x = float(position_str[0].strip()) if isinstance(position_str, list) else float(row['x'])
                y = float(position_str[1].strip()) if isinstance(position_str, list) else float(row['y'])

                self.positions['drones'][drone_id] = (x, y)
                self.drone_capacity[drone_id] = {
                    'full': float(row['Fullm']),
                    'current': float(row['Currentm']),
                    'range': float(row['uavRge']),
                    'uptime': int(row['U_uptime']),
                    'downtime': int(row['U_downtime'])
                }
                self.mobility_radii['drones'][drone_id] = float(row['uavRge'])

        # 加载工人数据
        with open(worker_file, 'r') as f_worker:
            reader_worker = csv.DictReader(f_worker)
            for row in reader_worker:
                worker_id = row['ID']
                position_str = row['x,y'].split(',') if 'x,y' in row else [row['x'], row['y']]
                x = float(position_str[0].strip()) if isinstance(position_str, list) else float(row['x'])
                y = float(position_str[1].strip()) if isinstance(position_str, list) else float(row['y'])

                self.positions['workers'][worker_id] = (x, y)
                self.worker_info[worker_id] = {
                    'range': float(row['workerRge']),
                    'uptime': int(row['W_uptime']),
                    'downtime': int(row['W_downtime'])
                }
                self.mobility_radii['workers'][worker_id] = float(row['workerRge'])

        # 加载任务数据
        with open(task_file, 'r') as f_task:
            reader_task = csv.DictReader(f_task)
            for row in reader_task:
                task_id = row['ID']
                position_str = row['x,y'].split(',') if 'x,y' in row else [row['x'], row['y']]
                x = float(position_str[0].strip()) if isinstance(position_str, list) else float(row['x'])
                y = float(position_str[1].strip()) if isinstance(position_str, list) else float(row['y'])

                self.positions['tasks'][task_id] = (x, y)
                self.task_data[task_id] = float(row['T_costData'])

        # 加载数据中心数据
        self.positions['data_centers'] = {}
        with open(dc_file, 'r') as f_dc:
            reader_dc = csv.DictReader(f_dc)
            for i, row in enumerate(reader_dc):
                dc_id = f"DC{i + 1}"
                position_str = row['x,y'].split(',') if 'x,y' in row else [row['x'], row['y']]
                x = float(position_str[0].strip()) if isinstance(position_str, list) else float(row['x'])
                y = float(position_str[1].strip()) if isinstance(position_str, list) else float(row['y'])
                self.positions['data_centers'][dc_id] = (x, y)

        # 初始化任务分配状态
        self.task_assignment = {task_id: False for task_id in self.positions['tasks']}

    def _dist(self, pos1, pos2, tolerance=1e-3):
        """计算两点之间的欧氏距离"""
        pos1 = self._ensure_position_format(pos1)
        pos2 = self._ensure_position_format(pos2)

        dx = pos1[0] - pos2[0]
        dy = pos1[1] - pos2[1]
        distance = math.sqrt(dx * dx + dy * dy)

        if abs(distance) < tolerance:
            return 0.0
        return distance

    def _ensure_position_format(self, pos):
        """确保位置是数值元组"""
        if isinstance(pos, tuple) and len(pos) == 2:
            return pos
        if isinstance(pos, str):
            try:
                cleaned = pos.strip("()")
                parts = cleaned.split(',')
                return (float(parts[0].strip()), float(parts[1].strip()))
            except:
                return (0, 0)
        return (0, 0)

    def _closest_data_center(self, position):
        """找到距离最近的数据中心"""
        min_dist = float('inf')
        closest_dc = None

        for dc_id in sorted(self.positions['data_centers'].keys()):
            dc_pos = self.positions['data_centers'][dc_id]
            dist = self._dist(position, dc_pos)
            if dist < min_dist:
                min_dist = dist
                closest_dc = dc_pos

        return closest_dc, min_dist

    def _calculate_weight(self, node_type, drone_id=None, worker_id=None, task_id=None):
        """计算节点权重"""
        drone_id = str(drone_id) if drone_id else None
        worker_id = str(worker_id) if worker_id else None
        task_id = str(task_id) if task_id else None

        # 获取无人机容量信息
        if drone_id:
            drone_info = self.drone_capacity.get(drone_id, {})
            full_M = drone_info.get('full', 30)
            curr_M = drone_info.get('current', 3)
            drone_range = drone_info.get('range', 1)
        else:
            full_M = 30
            curr_M = 3
            drone_range = 1

        # 获取任务数据量
        Mx = self.task_data.get(task_id, 0) if task_id else 0

        # 计算时间成本 Ts
        Ts = 1

        # 根据节点类型计算移动时间
        if node_type == "UiTx":
            if drone_id and task_id:
                drone_pos = self.positions['drones'][drone_id]
                distance = self._dist(drone_pos, self.positions['tasks'][task_id])
                Ts = max(1, math.ceil(distance / drone_range))

        elif node_type == "WjTx":
            if worker_id and task_id:
                worker_pos = self.positions['workers'][worker_id]
                distance = self._dist(worker_pos, self.positions['tasks'][task_id])
                worker_range = self.mobility_radii['workers'].get(worker_id, 1)
                Ts = max(1, math.ceil(distance / worker_range))

        elif node_type == "UiCy":
            if drone_id:
                drone_pos = self.positions['drones'][drone_id]
                _, dist_to_dc = self._closest_data_center(drone_pos)
                Ts = max(1, math.ceil(dist_to_dc / drone_range))

        elif node_type == "UiTxWj":
            if drone_id and worker_id and task_id:
                drone_pos = self.positions['drones'][drone_id]
                worker_pos = self.positions['workers'][worker_id]
                task_pos = self.positions['tasks'][task_id]

                drone_time = max(1, math.ceil(self._dist(drone_pos, task_pos) / drone_range))
                worker_range = self.mobility_radii['workers'].get(worker_id, 1)
                worker_time = max(1, math.ceil(self._dist(worker_pos, task_pos) / worker_range))
                Ts = max(drone_time, worker_time)

        # 根据不同节点类型计算最终权重
        if node_type == "UiTxWj":
            Rt = 1 * ((full_M - curr_M) / full_M) / Ts
            return Rt
        elif node_type == "UiCy":
            Rc = 1 * (1 - ((full_M - curr_M) / full_M)) / Ts
            return Rc
        elif node_type == "UiTx":
            return 0
        elif node_type == "WjTx":
            return 0
        elif node_type in ["Ui", "Wj"]:
            return 0
        else:
            return 0

    def _is_entity_online(self, entity_type, entity_id):
        """检查实体是否在线"""
        if entity_type == 'drone':
            info = self.drone_capacity.get(entity_id, {})
            uptime = info.get('uptime', 0)
            downtime = info.get('downtime', self.time_steps)
            return uptime <= self.current_time_step <= downtime
        elif entity_type == 'worker':
            info = self.worker_info.get(entity_id, {})
            uptime = info.get('uptime', 0)
            downtime = info.get('downtime', self.time_steps)
            return uptime <= self.current_time_step <= downtime
        return False

    def _get_available_time(self, entity_type, entity_id):
        """计算实体可用的最大时间"""
        simulation_time_available = self.time_steps - self.current_time_step

        if entity_type == 'drones':
            downtime = self.drone_capacity[entity_id].get('downtime', self.time_steps)
        elif entity_type == 'workers':
            downtime = self.worker_info[entity_id].get('downtime', self.time_steps)
        else:
            return simulation_time_available

        online_time_available = downtime - self.current_time_step
        return min(simulation_time_available, online_time_available)

    def _can_reach_in_available_time(self, entity_type, entity_id, target_pos):
        """检查实体是否能在可用时间内到达目标位置"""
        current_pos = self.positions[entity_type][entity_id]
        distance = self._dist(current_pos, target_pos)
        move_radius = self.mobility_radii[entity_type][entity_id]

        required_steps = math.ceil(distance / move_radius) if move_radius > 0 else 0
        available_time = self._get_available_time(entity_type, entity_id)

        return required_steps <= available_time

    def _can_unload_after_task(self, drone_id, worker_id, task_id):
        """检查无人机在协作任务完成后是否有足够时间移动到数据中心卸载数据"""
        task_pos = self.positions['tasks'][task_id]
        drone_current_pos = self.positions['drones'][drone_id]
        drone_distance_to_task = self._dist(drone_current_pos, task_pos)
        drone_move_radius = self.mobility_radii['drones'][drone_id]

        drone_steps_to_task = max(1, math.ceil(drone_distance_to_task / drone_move_radius))

        worker_current_pos = self.positions['workers'][worker_id]
        worker_distance_to_task = self._dist(worker_current_pos, task_pos)
        worker_move_radius = self.mobility_radii['workers'][worker_id]

        worker_steps_to_task = max(1, math.ceil(worker_distance_to_task / worker_move_radius))

        task_start_step = self.current_time_step + max(drone_steps_to_task, worker_steps_to_task) + 1

        dc_pos, _ = self._closest_data_center(task_pos)
        distance_to_dc = self._dist(task_pos, dc_pos)
        steps_to_dc = max(1, math.ceil(distance_to_dc / drone_move_radius))

        unload_complete_step = task_start_step + steps_to_dc + 1

        drone_downtime = self.drone_capacity[drone_id].get('downtime', self.time_steps)
        simulation_end = self.time_steps

        return unload_complete_step <= min(drone_downtime, simulation_end)

    def _update_moving_entities(self):
        """更新移动中的实体位置"""
        self.newly_arrived_entities.clear()

        # 更新移动中的无人机
        for drone_id in sorted(self.moving_entities['drones'].keys()):
            move_info = self.moving_entities['drones'][drone_id]
            if not self._is_entity_online('drone', drone_id):
                del self.moving_entities['drones'][drone_id]
                continue

            current_pos = self.positions['drones'][drone_id]
            target_pos = move_info['target']
            distance_to_target = self._dist(current_pos, target_pos)
            max_move = self.mobility_radii['drones'][drone_id]

            if distance_to_target <= max_move:
                # 到达目标位置
                if 'task_id' in move_info and move_info['task_id']:
                    action = f"协作任务: 到达任务点 {move_info['task_id']}"
                elif target_pos in self.positions['data_centers'].values():
                    action = "到达数据中心并卸载数据"
                else:
                    action = "到达"

                if target_pos in self.positions['data_centers'].values():
                    if self.drone_capacity[drone_id]['current'] > 0:
                        data_offloaded = self.drone_capacity[drone_id]['current']
                        self.data_offloaded += data_offloaded
                        self.drone_capacity[drone_id]['current'] = 0

                self.positions['drones'][drone_id] = target_pos
                self.movement_history['drones'][drone_id].append(
                    (self.current_time_step, action, target_pos)
                )

                self.newly_arrived_entities.add(('drone', drone_id))
                del self.moving_entities['drones'][drone_id]

                if 'task_id' in move_info and move_info['task_id'] is not None:
                    task_id = move_info['task_id']
                    if move_info.get('node_type') == 'UiTxWj' and task_id in self.collaboration_status:
                        self.collaboration_status[task_id]['drone_arrived'] = True
            else:
                # 继续移动
                direction = (
                    (target_pos[0] - current_pos[0]) / distance_to_target,
                    (target_pos[1] - current_pos[1]) / distance_to_target
                )
                new_pos = (
                    current_pos[0] + direction[0] * max_move,
                    current_pos[1] + direction[1] * max_move
                )
                self.positions['drones'][drone_id] = new_pos

                if 'task_id' in move_info and move_info['task_id']:
                    action = f"移动中到任务点 {move_info['task_id']}"
                elif target_pos in self.positions['data_centers'].values():
                    action = "移动中到数据中心"
                else:
                    action = "移动中"

                self.movement_history['drones'][drone_id].append(
                    (self.current_time_step, action, new_pos)
                )

        # 更新移动中的工人
        for worker_id in sorted(self.moving_entities['workers'].keys()):
            move_info = self.moving_entities['workers'][worker_id]
            if not self._is_entity_online('worker', worker_id):
                del self.moving_entities['workers'][worker_id]
                continue

            current_pos = self.positions['workers'][worker_id]
            target_pos = move_info['target']
            distance_to_target = self._dist(current_pos, target_pos)
            max_move = self.mobility_radii['workers'][worker_id]

            if distance_to_target <= max_move:
                # 到达目标位置
                if 'task_id' in move_info and move_info['task_id']:
                    action = f"协作任务: 到达任务点 {move_info['task_id']}"
                else:
                    action = "到达"

                self.positions['workers'][worker_id] = target_pos
                self.movement_history['workers'][worker_id].append(
                    (self.current_time_step, action, target_pos)
                )

                self.newly_arrived_entities.add(('worker', worker_id))
                del self.moving_entities['workers'][worker_id]
                self.worker_availability[worker_id] = True

                if 'task_id' in move_info and move_info['task_id'] is not None:
                    task_id = move_info['task_id']
                    if task_id in self.collaboration_status:
                        self.collaboration_status[task_id]['worker_arrived'] = True
            else:
                # 继续移动
                direction = (
                    (target_pos[0] - current_pos[0]) / distance_to_target,
                    (target_pos[1] - current_pos[1]) / distance_to_target
                )
                new_pos = (
                    current_pos[0] + direction[0] * max_move,
                    current_pos[1] + direction[1] * max_move
                )
                self.positions['workers'][worker_id] = new_pos

                if 'task_id' in move_info and move_info['task_id']:
                    action = f"移动中到任务点 {move_info['task_id']}"
                else:
                    action = "移动中"

                self.movement_history['workers'][worker_id].append(
                    (self.current_time_step, action, new_pos)
                )

    def _check_collaboration_completion(self, update_details):
        """检查协作任务是否完成"""
        tasks_to_remove = []

        for task_id in sorted(self.collaboration_status.keys()):
            status = self.collaboration_status[task_id]
            if status['drone_arrived'] and status['worker_arrived']:
                self.collaboration_waiting['drones'].add(status['drone_id'])
                self.collaboration_waiting['workers'].add(status['worker_id'])

                if self.task_status.get(task_id) == '未完成':
                    Mx = self.task_data[task_id]
                    drone_id = status['drone_id']
                    self.drone_capacity[drone_id]['current'] += Mx
                    self.task_data[task_id] = 0
                    self.task_status[task_id] = '已完成'
                    update_details['tasks_completed'].append(task_id)
                    update_details['data_collected'] += Mx
                    tasks_to_remove.append(task_id)

        for task_id in tasks_to_remove:
            drone_id = self.collaboration_status[task_id]['drone_id']
            worker_id = self.collaboration_status[task_id]['worker_id']
            self.collaboration_waiting['drones'].discard(drone_id)
            self.collaboration_waiting['workers'].discard(worker_id)
            del self.collaboration_status[task_id]

    def _generate_all_nodes(self):
        """生成所有可能的节点类型"""
        self.entity_queues = {'drone': defaultdict(list), 'worker': defaultdict(list)}

        if not hasattr(self, 'task_assignment'):
            self.task_assignment = {task_id: False for task_id in self.positions['tasks']}

        task_ids = sorted(self.positions['tasks'].keys(), key=lambda x: int(x))

        available_drones = sorted([
            id for id in self.positions['drones']
            if (id not in self.moving_entities['drones'] and
                ('drone', id) not in self.newly_arrived_entities and
                id not in self.collaboration_waiting['drones'] and
                self._is_entity_online('drone', id))
        ], key=lambda x: int(x))

        available_workers = sorted([
            id for id in self.positions['workers']
            if (id not in self.moving_entities['workers'] and
                ('worker', id) not in self.newly_arrived_entities and
                id not in self.collaboration_waiting['workers'] and
                self.worker_availability.get(id, True) and
                self._is_entity_online('worker', id))
        ], key=lambda x: int(x))

        active_collaborative_tasks = set()
        for task_id, status in self.collaboration_status.items():
            active_collaborative_tasks.add(task_id)

        # 1. 生成协作任务节点
        for drone_id in available_drones:
            drone_cap = self.drone_capacity[drone_id]
            if drone_cap['current'] >= drone_cap['full']:
                continue

            for worker_id in available_workers:
                for task_id in task_ids:
                    if (self.task_status.get(task_id) == '已完成' or
                            self.task_assignment.get(task_id, False) or
                            task_id in active_collaborative_tasks):
                        continue

                    if not self._can_complete_collaboration_in_online_time(drone_id, worker_id, task_id):
                        continue

                    constraint1 = self._check_drone_capacity(drone_id, task_id)
                    constraint2 = self._can_reach_in_available_time('drones', drone_id,
                                                                    self.positions['tasks'][task_id])
                    constraint3 = self._can_reach_in_available_time('workers', worker_id,
                                                                    self.positions['tasks'][task_id])
                    constraint4 = self._can_unload_after_task(drone_id, worker_id, task_id)

                    if constraint1 and constraint2 and constraint3 and constraint4:
                        node = f"UiTxWj_{drone_id}_{worker_id}_{task_id}"
                        weight = self._calculate_weight("UiTxWj",
                                                        drone_id=drone_id,
                                                        worker_id=worker_id,
                                                        task_id=task_id)
                        self._add_to_queue('drone', drone_id, node, weight)
                        self._add_to_queue('worker', worker_id, node, weight)

        # 2. 生成无人机去数据中心节点
        for drone_id in available_drones:
            if self.drone_capacity[drone_id]['current'] <= 0:
                continue

            dc_pos, dist_to_dc = self._closest_data_center(self.positions['drones'][drone_id])

            if not self._can_reach_in_available_time('drones', drone_id, dc_pos):
                continue

            node = f"UiCy_{drone_id}"
            weight = self._calculate_weight("UiCy", drone_id=drone_id)
            self._add_to_queue('drone', drone_id, node, weight)

        # 3. 生成无人机去任务点节点
        for drone_id in available_drones:
            drone_cap = self.drone_capacity[drone_id]
            if drone_cap['current'] >= drone_cap['full']:
                continue

            for task_id in task_ids:
                if (self.task_status.get(task_id) == '已完成' or
                        self.task_assignment.get(task_id, False) or
                        task_id in active_collaborative_tasks):
                    continue

                if not self._can_reach_in_available_time('drones', drone_id, self.positions['tasks'][task_id]):
                    continue

                node = f"UiTx_{drone_id}_{task_id}"
                weight = self._calculate_weight("UiTx", drone_id=drone_id, task_id=task_id)
                self._add_to_queue('drone', drone_id, node, weight)

        # 4. 生成工人去任务点节点
        for worker_id in available_workers:
            for task_id in task_ids:
                if (self.task_status.get(task_id) == '已完成' or
                        self.task_assignment.get(task_id, False) or
                        task_id in active_collaborative_tasks):
                    continue

                if not self._can_reach_in_available_time('workers', worker_id, self.positions['tasks'][task_id]):
                    continue

                node = f"WjTx_{worker_id}_{task_id}"
                weight = self._calculate_weight("WjTx", worker_id=worker_id, task_id=task_id)
                self._add_to_queue('worker', worker_id, node, weight)

        # 5. 生成无人机原地节点
        for drone_id in available_drones:
            drone_cap = self.drone_capacity[drone_id]
            if drone_cap['current'] >= drone_cap['full']:
                node = f"UiCy_{drone_id}"
                weight = self._calculate_weight("UiCy", drone_id=drone_id)
                self._add_to_queue('drone', drone_id, node, weight)
                continue

            node = f"Ui_{drone_id}"
            weight = self._calculate_weight("Ui", drone_id=drone_id)
            self._add_to_queue('drone', drone_id, node, weight)

        # 6. 工人原地节点
        for worker_id in available_workers:
            node = f"Wj_{worker_id}"
            weight = self._calculate_weight("Wj", worker_id=worker_id)
            self._add_to_queue('worker', worker_id, node, weight)

        # 创建统一的优先级列表
        self.priority_nodes = []

        for entity_type in ['drone', 'worker']:
            for entity_id in sorted(self.entity_queues[entity_type].keys()):
                queue = self.entity_queues[entity_type][entity_id]
                for node, weight in queue:
                    self.priority_nodes.append((node, weight, entity_type, entity_id))

        self.priority_nodes.sort(key=lambda x: (x[1], x[0]), reverse=True)

    def _can_complete_collaboration_in_online_time(self, drone_id, worker_id, task_id):
        """检查无人机和工人是否都能在各自的在线时间内完成协作任务"""
        drone_downtime = self.drone_capacity[drone_id].get('downtime', self.time_steps)
        worker_downtime = self.worker_info[worker_id].get('downtime', self.time_steps)

        task_completion_time = self._calculate_task_completion_time(drone_id, worker_id, task_id)

        drone_can_complete = (self.current_time_step + task_completion_time) <= drone_downtime
        worker_can_complete = (self.current_time_step + task_completion_time) <= worker_downtime

        return drone_can_complete and worker_can_complete

    def _calculate_task_completion_time(self, drone_id, worker_id, task_id):
        """计算协作任务完成所需的时间步数"""
        task_pos = self.positions['tasks'][task_id]

        drone_current_pos = self.positions['drones'][drone_id]
        drone_distance_to_task = self._dist(drone_current_pos, task_pos)
        drone_move_radius = self.mobility_radii['drones'][drone_id]
        drone_steps_to_task = max(1, math.ceil(drone_distance_to_task / drone_move_radius))

        worker_current_pos = self.positions['workers'][worker_id]
        worker_distance_to_task = self._dist(worker_current_pos, task_pos)
        worker_move_radius = self.mobility_radii['workers'][worker_id]
        worker_steps_to_task = max(1, math.ceil(worker_distance_to_task / worker_move_radius))

        task_start_step = max(drone_steps_to_task, worker_steps_to_task) + 1

        dc_pos, _ = self._closest_data_center(task_pos)
        distance_to_dc = self._dist(task_pos, dc_pos)
        steps_to_dc = max(1, math.ceil(distance_to_dc / drone_move_radius))

        unload_complete_step = task_start_step + steps_to_dc + 1
        return unload_complete_step

    def _check_drone_capacity(self, drone_id, task_id):
        """检查无人机容量是否足够"""
        Mx = self.task_data[task_id]
        drone_cap = self.drone_capacity[drone_id]
        available_capacity = drone_cap['full'] - drone_cap['current']
        return available_capacity >= Mx

    def _add_to_queue(self, entity_type, entity_id, node, weight):
        """添加节点到相应实体的队列"""
        if entity_id not in self.entity_queues[entity_type]:
            self.entity_queues[entity_type][entity_id] = []

        self.entity_queues[entity_type][entity_id].append((node, weight))
        self.entity_queues[entity_type][entity_id].sort(key=lambda x: (x[1], x[0]), reverse=True)

    def schedule(self, time_step):
        """执行单个时间步的调度过程"""
        self.current_time_step = time_step

        self.mis_solver = IncrementalMIS()
        self._update_moving_entities()

        temp_details = {
            'tasks_completed': [],
            'data_collected': 0,
            'data_offloaded': 0,
            'positions_changed': []
        }
        self._check_collaboration_completion(temp_details)

        self._generate_all_nodes()

        # 批量添加节点策略
        improved = True
        iteration = 0
        max_iterations = 20
        no_improve_count = 0
        no_improve_threshold = 2

        all_nodes = []
        for entity_type in ['drone', 'worker']:
            for entity_id in sorted(self.entity_queues[entity_type].keys()):
                queue = self.entity_queues[entity_type][entity_id]
                all_nodes.extend(queue)

        remaining_nodes = all_nodes.copy()

        while improved and iteration < max_iterations and remaining_nodes:
            iteration += 1

            batch_nodes = []
            for entity_type in ['drone', 'worker']:
                for entity_id in sorted(self.entity_queues[entity_type].keys()):
                    if self.entity_queues[entity_type][entity_id]:
                        node, weight = self.entity_queues[entity_type][entity_id].pop(0)
                        batch_nodes.append((node, weight))
                        remaining_nodes.remove((node, weight))

            if not batch_nodes:
                break

            added = self.mis_solver.add_nodes(batch_nodes)
            if not added:
                continue

            improved = self.mis_solver.optimize()

            if improved:
                no_improve_count = 0
            else:
                no_improve_count += 1

            if no_improve_count >= no_improve_threshold:
                self.mis_solver.add_remaining_nodes(remaining_nodes)
                remaining_nodes = []
                break

        if remaining_nodes:
            self.mis_solver.add_remaining_nodes(remaining_nodes)

        # 最终求解
        solution, weight = self.mis_solver.solve()

        # 分析结果并更新状态
        step_result = self._analyze_solution(solution, time_step)

        # 存储结果
        step_result['solution'] = solution
        step_result['total_weight'] = weight
        self.simulation_results.append(step_result)

        # 最后一个时间步强制卸载
        if time_step == self.time_steps:
            for drone_id in sorted(self.positions['drones'].keys()):
                if self.drone_capacity[drone_id]['current'] > 0:
                    dc_pos, dist_to_dc = self._closest_data_center(self.positions['drones'][drone_id])
                    max_move = self.mobility_radii['drones'][drone_id]

                    if dist_to_dc <= max_move:
                        self.positions['drones'][drone_id] = dc_pos
                        data_offloaded = self.drone_capacity[drone_id]['current']
                        self.data_offloaded += data_offloaded
                        self.drone_capacity[drone_id]['current'] = 0
                        self.movement_history['drones'][drone_id].append(
                            (time_step, "强制移动到数据中心并卸载", dc_pos)
                        )

        return solution, weight

    def run_simulation(self):
        """运行多时刻模拟"""
        import datetime
        start_time = datetime.datetime.now()

        # 运行每个时间步
        for t in range(1, self.time_steps + 1):
            self.schedule(t)

        end_time = datetime.datetime.now()
        elapsed_time = end_time - start_time

        # 输出最终结果
        self._print_final_results(elapsed_time)

        return self.simulation_results

    def _print_final_results(self, elapsed_time):
        """打印最终模拟结果"""
        print("=" * 80)
        print("=== 模拟最终结果 ===")
        print("=" * 80)
        print()

        # 计算任务完成率
        total_tasks = len(self.task_status)
        completed_tasks = sum(1 for status in self.task_status.values() if status == '已完成')
        completion_rate = (completed_tasks / total_tasks) * 100 if total_tasks > 0 else 0

        print(f"任务完成率: {completion_rate:.2f}% ({completed_tasks}/{total_tasks})")
        print(f"模拟运行时间: {elapsed_time.total_seconds():.3f} 秒")
        print(f"总卸载数据量: {self.data_offloaded:.1f}")
        print(f"完成任务: {completed_tasks}/{total_tasks}")
        print()

        # 时间步摘要表格
        print("时间步 | 解决方案节点数 | 权重   | 完成任务 | 收集数据 | 卸载数据 | 剩余任务")
        print("------|---------------|--------|---------|----------|----------|--------")
        for result in self.simulation_results:
            ts = result['time_step']
            node_count = len(result['solution'])
            weight = result['total_weight']
            tasks_completed = len(result['tasks_completed'])
            data_collected = result['data_collected']
            data_offloaded = result['data_offloaded']
            remaining_tasks = result['remaining_tasks']

            print(
                f"{ts:5} | {node_count:13} | {weight:6.4f} | {tasks_completed:7} | {data_collected:8.1f} | {data_offloaded:8.1f} | {remaining_tasks:7}")

        # 详细时间步完成情况
        print()
        print("=== 详细时间步完成情况 ===")
        for result in self.simulation_results:
            ts = result['time_step']
            solution = result['solution']
            tasks_completed = result['tasks_completed']

            print(f"\n时间步 {ts}:")
            if tasks_completed:
                print(f"  解决方案节点: {sorted(solution)}")
                print(f"  完成任务: {tasks_completed}")
            else:
                print(f"  解决方案节点: {sorted(solution)}")
                print(f"  完成任务: 无")

        # 最终任务状态
        print()
        print("=== 最终任务状态 ===")
        for task_id in sorted(self.task_status.keys()):
            status = self.task_status[task_id]
            print(f"  任务 {task_id}: {status}")

        # 最终无人机状态
        print()
        print("=== 最终无人机状态 ===")
        for drone_id in sorted(self.drone_capacity.keys()):
            cap = self.drone_capacity[drone_id]
            pos = self.positions['drones'][drone_id]
            print(f"  无人机 {drone_id}: 位置={pos}, 数据={cap['current']:.1f}/{cap['full']:.1f}")

        # 无人机移动历史
        print()
        print("=== 无人机移动历史 ===")
        for drone_id in sorted(self.movement_history['drones'].keys()):
            history = self.movement_history['drones'][drone_id]
            print(f"\n无人机 {drone_id} 移动历史:")
            for entry in history:
                time_step, action, pos = entry
                print(f"  时间步 {time_step}: {action}, 位置={pos}")

        # 工人移动历史
        print()
        print("=== 工人移动历史 ===")
        for worker_id in sorted(self.movement_history['workers'].keys()):
            history = self.movement_history['workers'][worker_id]
            print(f"\n工人 {worker_id} 移动历史:")
            for entry in history:
                time_step, action, pos = entry
                print(f"  时间步 {time_step}: {action}, 位置={pos}")

        print()
        print("=" * 80)
        import datetime
        print(f"模拟结束时间: {datetime.datetime.now()}")
        print("=" * 80)

    def _analyze_solution(self, solution, time_step):
        """分析解决方案并更新状态"""
        update_details = self._update_entity_states(solution, time_step)

        step_result = {
            'time_step': time_step,
            'solution': solution,
            'tasks_completed': update_details['tasks_completed'],
            'data_collected': update_details['data_collected'],
            'data_offloaded': update_details['data_offloaded'],
            'remaining_tasks': sum(1 for status in self.task_status.values() if status == '未完成'),
            'total_data_offloaded': self.data_offloaded
        }

        return step_result

    def _update_entity_states(self, solution, time_step):
        """更新实体状态"""
        self.task_assignment = {task_id: False for task_id in self.positions['tasks']}
        update_details = {
            'tasks_completed': [],
            'data_collected': 0,
            'data_offloaded': 0,
            'positions_changed': []
        }

        assigned_drones = set()
        assigned_workers = set()
        completed_tasks_in_step = set()

        # 第一步：处理所有节点，标记任务为已分配
        for node in sorted(solution):
            parts = node.split('_')
            node_type = parts[0]
            drone_id = None
            worker_id = None
            task_id = None

            if node_type == "UiTx":
                drone_id = parts[1]
                task_id = parts[2]
            elif node_type == "WjTx":
                worker_id = parts[1]
                task_id = parts[2]
            elif node_type == "UiTxWj":
                drone_id = parts[1]
                worker_id = parts[2]
                task_id = parts[3]

            if task_id:
                self.task_assignment[task_id] = True

        # 第二步：执行节点操作
        for node in sorted(solution):
            parts = node.split('_')
            node_type = parts[0]
            drone_id = None
            worker_id = None
            task_id = None

            if node_type in ["Ui", "UiTx", "UiCy"]:
                drone_id = parts[1]
            elif node_type == "Wj":
                worker_id = parts[1]
            elif node_type == "WjTx":
                worker_id = parts[1]
            elif node_type == "UiTxWj":
                drone_id = parts[1]
                worker_id = parts[2]

            if node_type in ["UiTx", "WjTx", "UiTxWj"]:
                task_id = parts[2] if node_type != "UiTxWj" else parts[3]

            # 检查无人机是否已经被分配
            if drone_id and drone_id in assigned_drones:
                continue

            # 检查工人是否已经被分配
            if worker_id and worker_id in assigned_workers:
                continue

            # 标记实体已被分配
            if drone_id:
                assigned_drones.add(drone_id)
            if worker_id:
                assigned_workers.add(worker_id)

            # 根据节点类型更新状态
            if node_type == "UiTx":
                task_id = parts[2]
                task_pos = self.positions['tasks'][task_id]
                current_pos = self.positions['drones'][drone_id]
                distance = self._dist(current_pos, task_pos)
                max_move = self.mobility_radii['drones'][drone_id]

                if distance <= max_move:
                    self.positions['drones'][drone_id] = task_pos
                    update_details['positions_changed'].append(f"无人机 {drone_id} -> 任务点 {task_id}")

                    self.movement_history['drones'][drone_id].append(
                        (time_step, f"到达任务点 {task_id} (非协作任务)", task_pos)
                    )

                    self.newly_arrived_entities.add(('drone', drone_id))
                    self.task_assignment[task_id] = False
                else:
                    self.moving_entities['drones'][drone_id] = {
                        'target': task_pos,
                        'task_id': task_id,
                        'node_type': 'UiTx'
                    }
                    update_details['positions_changed'].append(f"无人机 {drone_id} 开始移动至任务点 {task_id}")

                    self.movement_history['drones'][drone_id].append(
                        (time_step, f"开始移动至任务点 {task_id} (非协作任务)", current_pos)
                    )

            elif node_type == "UiCy":
                dc_pos, _ = self._closest_data_center(self.positions['drones'][drone_id])
                current_pos = self.positions['drones'][drone_id]
                distance = self._dist(current_pos, dc_pos)
                max_move = self.mobility_radii['drones'][drone_id]
                data_offloaded = self.drone_capacity[drone_id]['current']

                if distance <= max_move:
                    self.positions['drones'][drone_id] = dc_pos
                    update_details['positions_changed'].append(f"无人机 {drone_id} -> 数据中心")

                    self.movement_history['drones'][drone_id].append(
                        (time_step, "到达数据中心并卸载数据", dc_pos)
                    )

                    self.newly_arrived_entities.add(('drone', drone_id))

                    if data_offloaded > 0:
                        self.data_offloaded += data_offloaded

                    self.drone_capacity[drone_id]['current'] = 0
                else:
                    self.moving_entities['drones'][drone_id] = {
                        'target': dc_pos,
                        'task_id': None,
                        'node_type': 'UiCy'
                    }
                    update_details['positions_changed'].append(f"无人机 {drone_id} 开始移动至数据中心")

                    self.movement_history['drones'][drone_id].append(
                        (time_step, "开始移动至数据中心", current_pos)
                    )

            elif node_type == "WjTx":
                task_id = parts[2]
                task_pos = self.positions['tasks'][task_id]
                current_pos = self.positions['workers'][worker_id]
                distance = self._dist(current_pos, task_pos)
                max_move = self.mobility_radii['workers'][worker_id]

                if distance <= max_move:
                    self.positions['workers'][worker_id] = task_pos
                    self.worker_availability[worker_id] = False
                    update_details['positions_changed'].append(f"工人 {worker_id} -> 任务点 {task_id}")
                    self.newly_arrived_entities.add(('worker', worker_id))
                    self.task_assignment[task_id] = False

                    self.movement_history['workers'][worker_id].append(
                        (time_step, f"到达任务点 {task_id}", task_pos)
                    )
                else:
                    self.moving_entities['workers'][worker_id] = {
                        'target': task_pos,
                        'task_id': task_id,
                        'node_type': 'WjTx'
                    }
                    self.worker_availability[worker_id] = False
                    update_details['positions_changed'].append(f"工人 {worker_id} 开始移动至任务点 {task_id}")

                    self.movement_history['workers'][worker_id].append(
                        (time_step, f"开始移动至任务点 {task_id}", current_pos)
                    )

            elif node_type == "UiTxWj":
                task_id = parts[3]
                task_pos = self.positions['tasks'][task_id]

                if task_id not in self.collaboration_status:
                    self.collaboration_status[task_id] = {
                        'drone_id': drone_id,
                        'worker_id': worker_id,
                        'drone_arrived': False,
                        'worker_arrived': False
                    }

                self.collaboration_waiting['drones'].add(drone_id)
                self.collaboration_waiting['workers'].add(worker_id)

                # 处理无人机移动
                drone_current = self.positions['drones'][drone_id]
                drone_distance = self._dist(drone_current, task_pos)
                drone_max_move = self.mobility_radii['drones'][drone_id]

                if drone_distance <= drone_max_move:
                    self.positions['drones'][drone_id] = task_pos
                    self.collaboration_status[task_id]['drone_arrived'] = True
                    self.newly_arrived_entities.add(('drone', drone_id))

                    self.movement_history['drones'][drone_id].append(
                        (time_step, f"协作任务: 到达任务点 {task_id}", task_pos)
                    )
                else:
                    self.moving_entities['drones'][drone_id] = {
                        'target': task_pos,
                        'task_id': task_id,
                        'node_type': 'UiTxWj'
                    }
                    self.collaboration_status[task_id]['drone_arrived'] = False

                    self.movement_history['drones'][drone_id].append(
                        (time_step, f"协作任务: 开始移动至任务点 {task_id}", drone_current)
                    )

                # 处理工人移动
                worker_current = self.positions['workers'][worker_id]
                worker_distance = self._dist(worker_current, task_pos)
                worker_max_move = self.mobility_radii['workers'][worker_id]

                if worker_distance <= worker_max_move:
                    self.positions['workers'][worker_id] = task_pos
                    self.worker_availability[worker_id] = False
                    self.collaboration_status[task_id]['worker_arrived'] = True
                    self.newly_arrived_entities.add(('worker', worker_id))

                    self.movement_history['workers'][worker_id].append(
                        (time_step, f"协作任务: 到达任务点 {task_id}", task_pos)
                    )
                else:
                    self.moving_entities['workers'][worker_id] = {
                        'target': task_pos,
                        'task_id': task_id,
                        'node_type': 'UiTxWj'
                    }
                    self.worker_availability[worker_id] = False
                    self.collaboration_status[task_id]['worker_arrived'] = False

                    self.movement_history['workers'][worker_id].append(
                        (time_step, f"协作任务: 开始移动至任务点 {task_id}", worker_current)
                    )

                update_details['positions_changed'].append(
                    f"无人机 {drone_id} 和工人 {worker_id} 开始/继续向任务点 {task_id} 移动"
                )

                if (self.collaboration_status[task_id]['drone_arrived'] and
                        self.collaboration_status[task_id]['worker_arrived'] and
                        task_id not in completed_tasks_in_step):

                    if self.task_status.get(task_id) == '未完成':
                        Mx = self.task_data[task_id]
                        if Mx > 0:
                            self.drone_capacity[drone_id]['current'] += Mx
                            self.task_data[task_id] = 0
                            self.task_status[task_id] = '已完成'
                            update_details['tasks_completed'].append(task_id)
                            update_details['data_collected'] += Mx
                            completed_tasks_in_step.add(task_id)

                            drone_id = self.collaboration_status[task_id]['drone_id']
                            worker_id = self.collaboration_status[task_id]['worker_id']
                            self.collaboration_waiting['drones'].discard(drone_id)
                            self.collaboration_waiting['workers'].discard(worker_id)
                            del self.collaboration_status[task_id]
                            completed_tasks_in_step.add(task_id)

                            if drone_id in self.moving_entities['drones']:
                                del self.moving_entities['drones'][drone_id]
                            if worker_id in self.moving_entities['workers']:
                                del self.moving_entities['workers'][worker_id]

        # 恢复工人的可用状态
        for worker_id in sorted(self.worker_availability.keys()):
            if worker_id not in self.moving_entities['workers']:
                self.worker_availability[worker_id] = True

        # 检查所有无人机是否在数据中心，如果是，则卸载数据
        for drone_id in sorted(self.positions['drones'].keys()):
            drone_pos = self.positions['drones'][drone_id]
            in_data_center = any(
                self._dist(drone_pos, dc_pos) < 1e-3
                for dc_pos in self.positions['data_centers'].values()
            )

            if in_data_center and self.drone_capacity[drone_id]['current'] > 0:
                data_offloaded = self.drone_capacity[drone_id]['current']
                self.data_offloaded += data_offloaded
                self.drone_capacity[drone_id]['current'] = 0
                self.movement_history['drones'][drone_id].append(
                    (time_step, "在数据中心卸载数据", drone_pos)
                )

        return update_details
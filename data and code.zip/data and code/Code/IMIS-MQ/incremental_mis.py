import copy
class IncrementalMIS:
    """增量式最大独立集算法"""

    def __init__(self, graph=None, weights=None, independent_set=None):
        """初始化MIS求解器"""
        self.graph = graph if graph is not None else {}
        self.weights = weights if weights is not None else {}
        self.status = {}
        self.independent_set = set()
        self.non_independent_set = set()

        if independent_set:
            for node in self.graph:
                if node in independent_set:
                    self.status[node] = 1
                    self.independent_set.add(node)
                else:
                    self.status[node] = 0
                    self.non_independent_set.add(node)

        self.queue1 = {}
        self.queue2 = {}
        self._build_queues()

    def _build_queues(self):
        """构建或更新队列1和队列2"""
        self.queue1 = {}
        self.queue2 = {}

        # 队列1: 非独立集节点 -> 其独立集邻居
        for node in sorted(self.non_independent_set):
            ind_neighbors = set()
            for neighbor in sorted(self.graph.get(node, set())):
                if self.status.get(neighbor) == 1:
                    ind_neighbors.add(neighbor)
            if ind_neighbors:
                self.queue1[node] = sorted(ind_neighbors)

        # 队列2: 独立集节点 -> 其非独立集邻居
        for node in sorted(self.independent_set):
            non_ind_neighbors = set()
            for neighbor in sorted(self.graph.get(node, set())):
                if self.status.get(neighbor) == 0:
                    non_ind_neighbors.add(neighbor)
            if non_ind_neighbors:
                self.queue2[node] = sorted(non_ind_neighbors)

    def current_weight(self):
        """计算当前独立集的总权重"""
        return sum(self.weights[node] for node in self.independent_set)

    def optimize(self):
        """优化阶段: 尝试通过局部交换改进独立集"""
        improved = False
        restart = True
        iteration = 0

        # 首先添加所有无冲突节点
        added_any = False
        for node in sorted(self.non_independent_set):
            if self.status[node] != 0:
                continue

            # 检查是否有冲突
            conflict = False
            for neighbor in sorted(self.graph.get(node, [])):
                if self.status.get(neighbor) == 1:
                    conflict = True
                    break

            if not conflict:
                self.status[node] = 1
                self.independent_set.add(node)
                self.non_independent_set.remove(node)
                added_any = True

        if added_any:
            self._build_queues()
            improved = True
            return improved

        # 添加独立集初始化
        if not self.independent_set and self.non_independent_set:
            nodes_by_weight = sorted(self.non_independent_set, key=lambda n: (self.weights[n], n), reverse=True)
            best_node = nodes_by_weight[0]
            self.status[best_node] = 1
            self.independent_set.add(best_node)
            self.non_independent_set.remove(best_node)
            self._build_queues()
            improved = True
            restart = True

        while restart:
            iteration += 1
            restart = False
            nodes = sorted(self.queue1.keys(), key=lambda n: (self.weights[n], n), reverse=True)

            for idx, node in enumerate(nodes):
                if self.status[node] != 0 or node not in self.queue1:
                    continue

                # 冲突检测
                if any(self.status.get(n) == 1 for n in self.graph.get(node, [])):
                    continue

                # 保存当前状态以便回滚
                old_status = copy.deepcopy(self.status)
                old_ind_set = self.independent_set.copy()
                old_non_ind_set = self.non_independent_set.copy()
                old_weight = self.current_weight()

                # 尝试将当前节点加入独立集
                self.status[node] = 1
                self.independent_set.add(node)
                self.non_independent_set.discard(node)

                # 移除该节点的所有独立集邻居
                removed_nodes = set()
                for neighbor in sorted(self.graph.get(node, set())):
                    if self.status.get(neighbor) == 1:
                        self.status[neighbor] = 0
                        self.independent_set.remove(neighbor)
                        self.non_independent_set.add(neighbor)
                        removed_nodes.add(neighbor)

                self._build_queues()

                # 检查被移除节点的非独立集邻居是否可以加入独立集
                candidates = set()
                for u in removed_nodes:
                    for neighbor in sorted(self.graph.get(u, set())):
                        if self.status.get(neighbor) == 0 and neighbor != node:
                            candidates.add(neighbor)

                # 按权重降序尝试加入候选节点
                added_nodes = set()
                for candidate in sorted(candidates, key=lambda n: (self.weights[n], n), reverse=True):
                    if self.status[candidate] != 0:
                        continue

                    conflict = False
                    for neighbor in sorted(self.graph.get(candidate, set())):
                        if self.status.get(neighbor) == 1:
                            conflict = True
                            break

                    if not conflict:
                        self.status[candidate] = 1
                        self.independent_set.add(candidate)
                        self.non_independent_set.remove(candidate)
                        added_nodes.add(candidate)

                if added_nodes:
                    self._build_queues()

                # 检查新独立集是否改进
                new_weight = self.current_weight()
                if new_weight > old_weight:
                    # 接受改进
                    self._build_queues()
                    improved = True
                    restart = True
                    break
                else:
                    # 回滚到之前的状态
                    self.status = old_status
                    self.independent_set = old_ind_set
                    self.non_independent_set = old_non_ind_set
                    self._build_queues()

        return improved

    def add_nodes(self, nodes):
        """批量添加多个节点到图中"""
        added_any = False

        # 添加所有节点到图中
        for node, weight in nodes:
            if node not in self.graph:
                self.graph[node] = set()
                self.weights[node] = weight
                self.status[node] = 0
                self.non_independent_set.add(node)
                added_any = True

        if not added_any:
            return False

        # 添加冲突边
        sorted_nodes = sorted(self.graph.keys())
        for i, node1 in enumerate(sorted_nodes):
            for node2 in sorted_nodes[i + 1:]:
                if self._are_conflicting(node1, node2):
                    self.graph[node1].add(node2)
                    self.graph[node2].add(node1)

        self._build_queues()
        return True

    def add_remaining_nodes(self, remaining_nodes):
        """快速添加剩余节点（严格避免冲突）"""
        added_any = False
        remaining_nodes.sort(key=lambda x: (x[1], x[0]), reverse=True)

        candidate_nodes = [(node, weight) for node, weight in remaining_nodes]

        for node, weight in candidate_nodes:
            if node not in self.weights:
                self.weights[node] = weight

            # 检查与当前独立集中所有节点的冲突
            conflict = False
            for neighbor in sorted(self.independent_set):
                if neighbor in self.graph.get(node, set()):
                    conflict = True
                    break

            # 检查与同一批次添加的其他节点冲突
            if not conflict:
                for added_node in sorted(self.independent_set):
                    if self._are_conflicting(node, added_node):
                        conflict = True
                        break

            if not conflict:
                self.status[node] = 1
                self.independent_set.add(node)
                if node in self.non_independent_set:
                    self.non_independent_set.remove(node)
                added_any = True
                if (node, weight) in remaining_nodes:
                    remaining_nodes.remove((node, weight))

        if added_any:
            self._build_queues()

        return added_any

    def _extract_entities(self, node):
        """提取节点中的所有实体ID"""
        parts = node.split('_')
        entities = set()

        if parts[0] == "Ui":
            if len(parts) > 1: entities.add(f"drone_{parts[1]}")
        elif parts[0] == "Wj":
            if len(parts) > 1: entities.add(f"worker_{parts[1]}")
        elif parts[0] == "UiTx":
            if len(parts) > 1: entities.add(f"drone_{parts[1]}")
        elif parts[0] == "WjTx":
            if len(parts) > 1: entities.add(f"worker_{parts[1]}")
        elif parts[0] == "UiCy":
            if len(parts) > 1: entities.add(f"drone_{parts[1]}")
        elif parts[0] == "UiTxWj":
            if len(parts) > 1: entities.add(f"drone_{parts[1]}")
            if len(parts) > 2: entities.add(f"worker_{parts[2]}")

        return entities

    def _are_conflicting(self, node1, node2):
        """冲突检测规则"""
        # 提取两个节点中的所有实体
        entities1 = self._extract_entities(node1)
        entities2 = self._extract_entities(node2)

        # 规则1: 实体冲突 - 只有同类型实体才会冲突
        for e1 in sorted(entities1):
            for e2 in sorted(entities2):
                if e1.split('_')[0] == e2.split('_')[0] and e1.split('_')[1] == e2.split('_')[1]:
                    return True

        # 规则2: 任务点冲突
        task1 = self._get_task(node1)
        task2 = self._get_task(node2)
        if task1 and task2 and task1 == task2:
            return True

        # 规则3: 时间冲突
        if node1.startswith(("UiTx", "WjTx", "UiTxWj", "UiCy")) and \
                node2.startswith(("UiTx", "WjTx", "UiTxWj", "UiCy")):
            e1 = self._extract_entities(node1)
            e2 = self._extract_entities(node2)
            for entity in sorted(e1):
                if entity in e2:
                    return True

        return False

    def _get_task(self, node):
        """获取节点关联的任务点ID"""
        parts = node.split('_')
        if parts[0] == "UiTxWj" and len(parts) > 3:
            return parts[3]
        elif parts[0] in ["UiTx", "WjTx"] and len(parts) > 2:
            return parts[2]
        return None

    def solve(self, max_iterations=100, no_improve_limit=3):
        """求解最大独立集"""
        no_improve_count = 0
        iteration = 0

        while iteration < max_iterations and no_improve_count < no_improve_limit:
            iteration += 1
            improved = self.optimize()

            if improved:
                no_improve_count = 0
            else:
                no_improve_count += 1

        return self.independent_set, self.current_weight()
import argparse
import os
from scheduler_kwta import MonteCarloKWTASchedulerFixed


def main():
    # 设置命令行参数解析
    parser = argparse.ArgumentParser(description='无人机-工人调度模拟（确定性K-WTA算法，原权重公式）')
    parser.add_argument('--dataset', type=str, default="Random_1",
                        help='数据集文件夹名称 (默认: Random_1)')
    parser.add_argument('--steps', type=int, default=20,
                        help='模拟时间步数 (默认: 20)')
    parser.add_argument('--k-value', type=int, default=3,
                        help='K-WTA中的K值 (默认: 3)')
    parser.add_argument('--num-trials', type=int, default=1000,
                        help='保留参数，不影响算法 (默认: 1000)')

    args = parser.parse_args()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "..", "..", "Data", args.dataset)
    data_dir = os.path.abspath(data_dir)

    scheduler = MonteCarloKWTASchedulerFixed(
        drone_file=os.path.join(data_dir, "uavMap.csv"),
        worker_file=os.path.join(data_dir, "workerMap.csv"),
        task_file=os.path.join(data_dir, "taskMap.csv"),
        dc_file=os.path.join(data_dir, "datacenterMap.csv"),
        time_steps=args.steps,
        k_value=args.k_value,
        num_trials=args.num_trials  # 保留参数，实际不使用
    )

    # 运行模拟
    results = scheduler.run_simulation()

    print(f"模拟完成，共运行 {args.steps} 个时间步")
    print(f"算法：确定性K-WTA（总是选择权重最高的{args.k_value}个不冲突动作）")


if __name__ == "__main__":
    main()
import qmix
import numpy as np
from data_loader import load_data_from_csv
from Tool import s_obs_avail_action, Update_Agent_Loc
from test import Test_Func
import os
import datetime
import time

if __name__ == '__main__':
    # ============ 记录程序开始时间 ============
    program_start_time = time.time()

    # 初始化日志系统
    log_dir = "training_logs"
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"training_log_{timestamp}.txt"
    log_path = os.path.join(log_dir, log_filename)

    # ============ 设置正确的文件路径 ============
    # 使用相对路径
    current_dir = os.path.dirname(os.path.abspath(__file__))  # Code/IMIS-MQ/
    data_folder = os.path.join(current_dir, "..", "..", "Data", "Random_1")
    data_folder = os.path.abspath(data_folder)

    # 完整的CSV文件路径
    task_file = os.path.join(data_folder, 'taskMap.csv')
    uav_file = os.path.join(data_folder, 'uavMap.csv')
    worker_file = os.path.join(data_folder, 'workerMap.csv')
    datacenter_file = os.path.join(data_folder, 'datacenterMap.csv')

    # 从CSV文件加载数据
    Data = load_data_from_csv(
        task_file=task_file,
        uav_file=uav_file,
        worker_file=worker_file,
        datacenter_file=datacenter_file
    )

    TimeLimit = 20

    # 提取数据
    Env = Data['Env']
    Agent_Sign = Data['Agent_Sign']
    Action_Dim = Data['Action_Dim']
    Agent_Loc = Data['Agent_Loc']
    Memory = Data['Memory']
    DataConsum = Data['DataConsum']
    Agent_Online = Data['Agent_Online']
    UAV_Fullm = Data['UAV_Fullm']
    task_cost_dict = Data['task_cost_dict']
    datacenter_positions = Data['datacenter_positions']
    worker_count = Data['worker_count']
    uav_count = Data['uav_count']

    # 从Data中获取动态计算的网格大小
    grid_size = Data.get('grid_size', (50, 50))  # 默认值
    rows, cols = grid_size

    Agent_Num = Agent_Sign.shape[0]

    print(f"📊 数据加载完成:")
    print(f"   - 智能体总数: {Agent_Num}")
    print(f"   - 无人机数量: {uav_count}")
    print(f"   - 工人数量: {worker_count}")
    print(f"   - 任务点数量: {len(task_cost_dict)}")
    print(f"   - 数据中心数量: {len(datacenter_positions)}")
    print(f"   - 动态计算网格大小: {rows} x {cols}")
    print(f"   - 时间限制: {TimeLimit}")

    # 初始化QMix算法
    qmix_algo = qmix.QMix(0.0001, 0.7, 1, 0.1, 5000, 32, 200, Agent_Num, rows, cols)
    filename_CNN = 'model/CNN/CNN'
    filename_agent = 'model/agent/agent'
    filename_qmixer = 'model/qmixer/qmixer'

    TrainNum = 50000

    print(f"\n🚀 开始训练，总共 {TrainNum} 轮")

    for episode in range(TrainNum):
        # 记录当前轮次的开始时间
        episode_start_time = time.time()

        # 初始化环境数据（从原始数据复制）
        Env_ = np.copy(Env)
        Agent_Sign_ = np.copy(Agent_Sign)
        Action_Dim_ = np.copy(Action_Dim)
        Agent_Loc_ = np.copy(Agent_Loc)
        Memory_ = np.copy(Memory)
        DataConsum_ = np.copy(DataConsum)
        Agent_Online_ = np.copy(Agent_Online)

        # 获取初始状态
        s, obs, avail_action = s_obs_avail_action(
            Env_, Agent_Sign_, Action_Dim_, Agent_Loc_, Memory_, DataConsum_,
            Agent_Online_, UAV_Fullm, 0, TimeLimit, datacenter_positions, worker_count
        )

        CurrTime = 0
        loss = 0
        total_unload_opp = 0
        total_completed_tasks = 0
        episode_data_unloaded = 0
        successful_unload = 0
        Data_Collected = [False for _ in range(Agent_Num)]
        UploadCooldown = [False for _ in range(Agent_Num)]
        AllTask = np.sum(Env_[1, :, :])

        while CurrTime < TimeLimit:
            CurrTime += 1

            # 选择动作
            action = qmix_algo.choose_action(s, obs, avail_action)

            # 更新环境
            Env_, Agent_Loc_, Memory_, r, task_completed, UploadCooldown, Data_Collected, \
                unload_opp, successful, step_data_unloaded = \
                Update_Agent_Loc(
                    Env_, Agent_Sign_, Memory_, DataConsum_, action, Agent_Online_,
                    UAV_Fullm, task_cost_dict, datacenter_positions, CurrTime, TimeLimit,
                    UploadCooldown, Data_Collected, Agent_Loc_, worker_count
                )

            # 更新统计
            episode_data_unloaded += step_data_unloaded
            total_completed_tasks += task_completed
            total_unload_opp += unload_opp
            successful_unload += successful

            # 获取下一状态
            s_next, obs_next, avail_action_next = s_obs_avail_action(
                Env_, Agent_Sign_, Action_Dim_, Agent_Loc_, Memory_, DataConsum_,
                Agent_Online_, UAV_Fullm, CurrTime, TimeLimit, datacenter_positions, worker_count
            )

            terminal_flag = 1 if CurrTime == TimeLimit else 0

            # 存储经验
            qmix_algo.store_transition(
                s, s_next, obs, obs_next, avail_action, avail_action_next, action, r, terminal_flag
            )

            # 学习
            if qmix_algo.memory_counter > qmix_algo.memory_size:
                loss = qmix_algo.learn()

            # 更新状态
            s = np.copy(s_next)
            obs = np.copy(obs_next)
            avail_action = np.copy(avail_action_next)

        # 记录当前轮次的结束时间
        episode_end_time = time.time()
        episode_duration = episode_end_time - episode_start_time

        # 计算累计时间
        total_elapsed_time = time.time() - program_start_time

        # 每轮训练结束后的统计
        if episode % 10 == 0:  # 每100轮输出一次
            # ✅ 回合结束，输出统计（添加时间信息）
            print(f"\n📘 Episode {episode} 完成.")
            print(f"⏱️  本轮用时: {episode_duration:.1f}秒")
            print(f"⏱️  累计用时: {total_elapsed_time:.1f}秒")

            if AllTask > 0:
                task_completion_rate = total_completed_tasks / AllTask
                print(f"✅ 完成任务: {total_completed_tasks} / {int(AllTask)}")
                print(f"📊 任务完成率: {task_completion_rate * 100:.2f}%")
            else:
                print("❌ 本回合没有任务.")

            print(f"📥 成功卸载次数: {successful_unload}")
            if total_unload_opp > 0:
                print(f"📊 卸载成功率: {successful_unload / total_unload_opp * 100:.2f}%")

            print(f"📦 总卸载数据量: {episode_data_unloaded:.1f} 单位")

        # 每500轮保存模型和测试
        if episode % 500 == 0:
            qmix_algo.save_model(filename_CNN, filename_agent, filename_qmixer)

            # 添加保存时间记录
            print(f"\n💾 模型已保存")

            # 测试代码
            result = np.zeros((TimeLimit,))
            data_unload_curve = np.zeros((TimeLimit,))

            for TimeLimit_ in range(TimeLimit):
                # 注意：需要修改Test_Func以支持新数据结构
                AllTask_test, ComplateTask_test, unload_curve = Test_Func(
                    Data, qmix_algo, TimeLimit_ + 1,
                    UAV_Fullm, task_cost_dict, datacenter_positions, worker_count
                )
                result[TimeLimit_] = ComplateTask_test / AllTask_test
                data_unload_curve[TimeLimit_] = np.sum(unload_curve)

            # 记录日志（添加时间信息）
            log_content = f"""
            =============== Episode {episode} ===============
            当前时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            累计运行: {total_elapsed_time:.1f}秒
            🧪 测试结果:
            任务完成率: {np.round(result, 4)}
            📉 训练损失: {loss:.4f}
            📦 每时间步数据卸载量: {np.round(data_unload_curve, 1)}
            ================================================
            """

            print(log_content)
            try:
                with open(log_path, "a", encoding='utf-8') as log_file:
                    log_file.write(log_content + "\n\n")
            except Exception as e:
                print(f"⚠️ 日志写入失败: {str(e)}")

            # 保留原有输出
            print(f"🧪 Episode {episode} 测试结果: {result}")
            print(f"📉 Episode {episode} 训练损失: {loss}")
            print(f"📦 每时间步数据卸载量: {data_unload_curve}")

    # ============ 训练结束后的总时间统计 ============
    program_end_time = time.time()
    total_program_time = program_end_time - program_start_time

    print(f"\n{'=' * 60}")
    print(f"🎉 训练完成! 总共 {TrainNum} 轮")
    print(f"⏱️  总运行时间: {total_program_time:.1f}秒")
    print(f"📅 开始时间: {datetime.datetime.fromtimestamp(program_start_time).strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"📅 结束时间: {datetime.datetime.fromtimestamp(program_end_time).strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"📈 平均每轮时间: {total_program_time / TrainNum:.1f}秒")
    print(f"{'=' * 60}")

    # 将总时间统计也写入日志
    final_summary = f"""
    =============== 训练完成 ===============
    总训练轮数: {TrainNum}
    总运行时间: {total_program_time:.1f}秒
    开始时间: {datetime.datetime.fromtimestamp(program_start_time).strftime('%Y-%m-%d %H:%M:%S')}
    结束时间: {datetime.datetime.fromtimestamp(program_end_time).strftime('%Y-%m-%d %H:%M:%S')}
    平均每轮时间: {total_program_time / TrainNum:.1f}秒
    ========================================
    """

    try:
        with open(log_path, "a", encoding='utf-8') as log_file:
            log_file.write(final_summary + "\n\n")
    except Exception as e:
        print(f"⚠️ 最终统计日志写入失败: {str(e)}")
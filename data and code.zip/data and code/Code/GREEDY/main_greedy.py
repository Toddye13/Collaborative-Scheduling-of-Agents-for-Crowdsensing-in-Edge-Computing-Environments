import argparse
import os
from scheduler_greedy import SimpleGreedyScheduler


def main():
    # 设置命令行参数解析
    parser = argparse.ArgumentParser(description='无人机-工人调度模拟')
    parser.add_argument('--dataset', type=str, default="Random_1",
                        help='数据集文件夹名称 (默认: Random_1)')
    parser.add_argument('--steps', type=int, default=20,
                        help='模拟时间步数 (默认: 20)')

    args = parser.parse_args()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "..", "..", "Data", args.dataset)
    data_dir = os.path.abspath(data_dir)

    # 创建调度器实例
    scheduler = SimpleGreedyScheduler(
        drone_file=os.path.join(data_dir, "uavMap.csv"),
        worker_file=os.path.join(data_dir, "workerMap.csv"),
        task_file=os.path.join(data_dir, "taskMap.csv"),
        dc_file=os.path.join(data_dir, "datacenterMap.csv"),
        time_steps=args.steps
    )

    # 运行模拟
    results = scheduler.run_simulation()

    print(f"模拟完成，共运行 {args.steps} 个时间步")


if __name__ == "__main__":
    main()
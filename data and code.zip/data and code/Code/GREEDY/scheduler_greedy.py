"""基于简化的贪心策略的无人机-工人调度器（使用原权重公式）"""

import csv
import math
import copy
from collections import defaultdict
from datetime import datetime

class SimpleGreedyScheduler:
    def __init__(self, drone_file="uavMap.csv", worker_file="workerMap.csv",
                 task_file="taskMap.csv", dc_file="datacenterMap.csv", time_steps=6):
        """初始化调度器"""
        self.positions = {
            'drones': {},
            'workers': {},
            'tasks': {},
            'data_centers': {}
        }
        self.drone_capacity = {}
        self.worker_info = {}
        self.task_data = {}
        self.mobility_radii = {
            'drones': {},
            'workers': {}
        }
        self.time_steps = time_steps
        self.simulation_results = []
        self.data_offloaded = 0
        self.current_time_step = 0

        # 实体状态
        self.moving_entities = {
            'drones': {},
            'workers': {}
        }
        self.movement_history = {
            'drones': {},
            'workers': {}
        }
        self.newly_arrived_entities = set()
        self.collaboration_waiting = {'drones': set(), 'workers': set()}
        self.collaboration_status = {}
        self.task_status = {}
        self.worker_availability = {}
        self.task_assignment = {}

        # 从CSV文件加载数据
        self._load_from_csv(drone_file, worker_file, task_file, dc_file)

        # 初始化状态
        self._initialize_states()

    def _load_from_csv(self, drone_file, worker_file, task_file, dc_file):
        """从CSV文件加载数据（与原代码相同）"""
        # 加载无人机数据
        with open(drone_file, 'r') as f_drone:
            reader_drone = csv.DictReader(f_drone)
            for row in reader_drone:
                drone_id = row['ID']
                position_str = row['x,y'].split(',') if 'x,y' in row else [row['x'], row['y']]
                x = float(position_str[0].strip()) if isinstance(position_str, list) else float(row['x'])
                y = float(position_str[1].strip()) if isinstance(position_str, list) else float(row['y'])

                self.positions['drones'][drone_id] = (x, y)
                self.drone_capacity[drone_id] = {
                    'full': float(row['Fullm']),
                    'current': float(row['Currentm']),
                    'range': float(row['uavRge']),
                    'uptime': int(row['U_uptime']),
                    'downtime': int(row['U_downtime'])
                }
                self.mobility_radii['drones'][drone_id] = float(row['uavRge'])

        # 加载工人数据
        with open(worker_file, 'r') as f_worker:
            reader_worker = csv.DictReader(f_worker)
            for row in reader_worker:
                worker_id = row['ID']
                position_str = row['x,y'].split(',') if 'x,y' in row else [row['x'], row['y']]
                x = float(position_str[0].strip()) if isinstance(position_str, list) else float(row['x'])
                y = float(position_str[1].strip()) if isinstance(position_str, list) else float(row['y'])

                self.positions['workers'][worker_id] = (x, y)
                self.worker_info[worker_id] = {
                    'range': float(row['workerRge']),
                    'uptime': int(row['W_uptime']),
                    'downtime': int(row['W_downtime'])
                }
                self.mobility_radii['workers'][worker_id] = float(row['workerRge'])

        # 加载任务数据
        with open(task_file, 'r') as f_task:
            reader_task = csv.DictReader(f_task)
            for row in reader_task:
                task_id = row['ID']
                position_str = row['x,y'].split(',') if 'x,y' in row else [row['x'], row['y']]
                x = float(position_str[0].strip()) if isinstance(position_str, list) else float(row['x'])
                y = float(position_str[1].strip()) if isinstance(position_str, list) else float(row['y'])

                self.positions['tasks'][task_id] = (x, y)
                self.task_data[task_id] = float(row['T_costData'])

        # 加载数据中心数据
        self.positions['data_centers'] = {}
        with open(dc_file, 'r') as f_dc:
            reader_dc = csv.DictReader(f_dc)
            for i, row in enumerate(reader_dc):
                dc_id = f"DC{i + 1}"
                position_str = row['x,y'].split(',') if 'x,y' in row else [row['x'], row['y']]
                x = float(position_str[0].strip()) if isinstance(position_str, list) else float(row['x'])
                y = float(position_str[1].strip()) if isinstance(position_str, list) else float(row['y'])
                self.positions['data_centers'][dc_id] = (x, y)

    def _initialize_states(self):
        """初始化状态"""
        # 任务状态
        self.task_status = {task_id: '未完成' for task_id in self.positions['tasks']}

        # 工人可用性
        for worker_id in self.positions['workers']:
            self.worker_availability[worker_id] = True

        # 任务分配状态
        self.task_assignment = {task_id: False for task_id in self.positions['tasks']}

        # 移动历史
        for drone_id, pos in self.positions['drones'].items():
            self.movement_history['drones'][drone_id] = []
            self.movement_history['drones'][drone_id].append((0, "初始位置", pos))
        for worker_id, pos in self.positions['workers'].items():
            self.movement_history['workers'][worker_id] = []
            self.movement_history['workers'][worker_id].append((0, "初始位置", pos))

    def _dist(self, pos1, pos2, tolerance=1e-3):
        """计算两点之间的欧氏距离"""
        if isinstance(pos1, str):
            pos1 = self._ensure_position_format(pos1)
        if isinstance(pos2, str):
            pos2 = self._ensure_position_format(pos2)

        dx = pos1[0] - pos2[0]
        dy = pos1[1] - pos2[1]
        distance = math.sqrt(dx * dx + dy * dy)

        if abs(distance) < tolerance:
            return 0.0
        return distance

    def _ensure_position_format(self, pos):
        """确保位置是数值元组"""
        if isinstance(pos, tuple) and len(pos) == 2:
            return pos
        if isinstance(pos, str):
            try:
                cleaned = pos.strip("()")
                parts = cleaned.split(',')
                return (float(parts[0].strip()), float(parts[1].strip()))
            except:
                return (0, 0)
        return (0, 0)

    def _closest_data_center(self, position):
        """找到距离最近的数据中心"""
        min_dist = float('inf')
        closest_dc = None

        for dc_id in sorted(self.positions['data_centers'].keys()):
            dc_pos = self.positions['data_centers'][dc_id]
            dist = self._dist(position, dc_pos)
            if dist < min_dist:
                min_dist = dist
                closest_dc = dc_pos

        return closest_dc, min_dist

    def _is_entity_online(self, entity_type, entity_id):
        """检查实体是否在线"""
        if entity_type == 'drone':
            info = self.drone_capacity.get(entity_id, {})
            uptime = info.get('uptime', 0)
            downtime = info.get('downtime', self.time_steps)
            return uptime <= self.current_time_step <= downtime
        elif entity_type == 'worker':
            info = self.worker_info.get(entity_id, {})
            uptime = info.get('uptime', 0)
            downtime = info.get('downtime', self.time_steps)
            return uptime <= self.current_time_step <= downtime
        return False

    def _get_available_time(self, entity_type, entity_id):
        """计算实体可用的最大时间"""
        simulation_time_available = self.time_steps - self.current_time_step

        if entity_type == 'drones':
            downtime = self.drone_capacity[entity_id].get('downtime', self.time_steps)
        elif entity_type == 'workers':
            downtime = self.worker_info[entity_id].get('downtime', self.time_steps)
        else:
            return simulation_time_available

        online_time_available = downtime - self.current_time_step
        return min(simulation_time_available, online_time_available)

    def _can_reach_in_available_time(self, entity_type, entity_id, target_pos):
        """检查实体是否能在可用时间内到达目标位置"""
        current_pos = self.positions[entity_type][entity_id]
        distance = self._dist(current_pos, target_pos)
        move_radius = self.mobility_radii[entity_type][entity_id]

        required_steps = math.ceil(distance / move_radius) if move_radius > 0 else 0
        available_time = self._get_available_time(entity_type, entity_id)

        return required_steps <= available_time

    def _update_moving_entities(self):
        """更新移动中的实体位置"""
        self.newly_arrived_entities.clear()

        # 更新移动中的无人机
        for drone_id in list(self.moving_entities['drones'].keys()):
            move_info = self.moving_entities['drones'][drone_id]
            if not self._is_entity_online('drone', drone_id):
                del self.moving_entities['drones'][drone_id]
                continue

            current_pos = self.positions['drones'][drone_id]
            target_pos = move_info['target']
            distance_to_target = self._dist(current_pos, target_pos)
            max_move = self.mobility_radii['drones'][drone_id]

            if distance_to_target <= max_move:
                # 到达目标位置
                action = move_info.get('action', '到达')
                self.positions['drones'][drone_id] = target_pos
                self.movement_history['drones'][drone_id].append(
                    (self.current_time_step, action, target_pos)
                )
                self.newly_arrived_entities.add(('drone', drone_id))

                # 如果是到达数据中心，卸载数据
                if move_info.get('destination_type') == 'data_center':
                    if self.drone_capacity[drone_id]['current'] > 0:
                        data_offloaded = self.drone_capacity[drone_id]['current']
                        self.data_offloaded += data_offloaded
                        self.drone_capacity[drone_id]['current'] = 0

                del self.moving_entities['drones'][drone_id]
            else:
                # 继续移动
                direction = (
                    (target_pos[0] - current_pos[0]) / distance_to_target,
                    (target_pos[1] - current_pos[1]) / distance_to_target
                )
                new_pos = (
                    current_pos[0] + direction[0] * max_move,
                    current_pos[1] + direction[1] * max_move
                )
                self.positions['drones'][drone_id] = new_pos
                action = move_info.get('action', '移动中')
                self.movement_history['drones'][drone_id].append(
                    (self.current_time_step, action, new_pos)
                )

        # 更新移动中的工人
        for worker_id in list(self.moving_entities['workers'].keys()):
            move_info = self.moving_entities['workers'][worker_id]
            if not self._is_entity_online('worker', worker_id):
                del self.moving_entities['workers'][worker_id]
                continue

            current_pos = self.positions['workers'][worker_id]
            target_pos = move_info['target']
            distance_to_target = self._dist(current_pos, target_pos)
            max_move = self.mobility_radii['workers'][worker_id]

            if distance_to_target <= max_move:
                # 到达目标位置
                action = move_info.get('action', '到达')
                self.positions['workers'][worker_id] = target_pos
                self.movement_history['workers'][worker_id].append(
                    (self.current_time_step, action, target_pos)
                )
                self.newly_arrived_entities.add(('worker', worker_id))
                self.worker_availability[worker_id] = True
                del self.moving_entities['workers'][worker_id]
            else:
                # 继续移动
                direction = (
                    (target_pos[0] - current_pos[0]) / distance_to_target,
                    (target_pos[1] - current_pos[1]) / distance_to_target
                )
                new_pos = (
                    current_pos[0] + direction[0] * max_move,
                    current_pos[1] + direction[1] * max_move
                )
                self.positions['workers'][worker_id] = new_pos
                action = move_info.get('action', '移动中')
                self.movement_history['workers'][worker_id].append(
                    (self.current_time_step, action, new_pos)
                )

    def _check_collaboration_completion(self):
        """检查协作任务是否完成"""
        tasks_to_remove = []

        for task_id in list(self.collaboration_status.keys()):
            status = self.collaboration_status[task_id]
            if status['drone_arrived'] and status['worker_arrived']:
                if self.task_status.get(task_id) == '未完成':
                    Mx = self.task_data[task_id]
                    drone_id = status['drone_id']
                    self.drone_capacity[drone_id]['current'] += Mx
                    self.task_data[task_id] = 0
                    self.task_status[task_id] = '已完成'
                    tasks_to_remove.append(task_id)

        for task_id in tasks_to_remove:
            del self.collaboration_status[task_id]

    # ==================== 简化的贪心策略（使用原权重公式）====================

    def _calculate_weight(self, action_type, drone_id=None, worker_id=None, task_id=None):
        """
        计算权重 - 使用与原算法完全相同的公式

        与原代码中的_calculate_weight函数保持一致：
        UiTxWj: Rt = 1 * ((full_M - curr_M) / full_M) / Ts
        UiCy: Rc = 1 * (1 - ((full_M - curr_M) / full_M)) / Ts
        UiTx: 0
        WjTx: 0
        Ui/Wj: 0
        """
        if not drone_id and action_type in ['collaborate', 'drone_to_dc', 'drone_to_task']:
            return 0

        # 获取无人机容量信息
        if drone_id:
            drone_info = self.drone_capacity.get(drone_id, {})
            full_M = drone_info.get('full', 30)
            curr_M = drone_info.get('current', 3)
            drone_range = drone_info.get('range', 1)
        else:
            full_M = 30
            curr_M = 3
            drone_range = 1

        # 获取任务数据量（如果相关）
        Mx = self.task_data.get(task_id, 0) if task_id else 0

        # 计算时间成本 Ts（与原代码相同）
        Ts = 1

        if action_type == 'collaborate':
            # 对应 UiTxWj
            if drone_id and worker_id and task_id:
                drone_pos = self.positions['drones'][drone_id]
                worker_pos = self.positions['workers'][worker_id]
                task_pos = self.positions['tasks'][task_id]

                drone_time = max(1, math.ceil(self._dist(drone_pos, task_pos) / drone_range))
                worker_range_val = self.mobility_radii['workers'].get(worker_id, 1)
                worker_time = max(1, math.ceil(self._dist(worker_pos, task_pos) / worker_range_val))
                Ts = max(drone_time, worker_time)

                # 原公式：Rt = 1 * ((full_M - curr_M) / full_M) / Ts
                Rt = 1 * ((full_M - curr_M) / full_M) / Ts
                return Rt

        elif action_type == 'drone_to_dc':
            # 对应 UiCy
            if drone_id:
                drone_pos = self.positions['drones'][drone_id]
                _, dist_to_dc = self._closest_data_center(drone_pos)
                Ts = max(1, math.ceil(dist_to_dc / drone_range))

                # 原公式：Rc = 1 * (1 - ((full_M - curr_M) / full_M)) / Ts
                Rc = 1 * (1 - ((full_M - curr_M) / full_M)) / Ts
                return Rc

        elif action_type == 'drone_to_task':
            # 对应 UiTx - 原代码返回0
            return 0

        elif action_type == 'worker_to_task':
            # 对应 WjTx - 原代码返回0
            return 0

        return 0

    def _simple_greedy_schedule(self):
        """
        简化的贪心调度算法
        使用与原算法相同的权重公式，但采用贪婪选择策略
        """
        scheduled_actions = []
        assigned_drones = set()
        assigned_workers = set()
        assigned_tasks = set()

        # 获取可用实体
        available_drones = [
            d for d in self.positions['drones']
            if (d not in self.moving_entities['drones'] and
                ('drone', d) not in self.newly_arrived_entities and
                d not in self.collaboration_waiting['drones'] and
                self._is_entity_online('drone', d))
        ]

        available_workers = [
            w for w in self.positions['workers']
            if (w not in self.moving_entities['workers'] and
                ('worker', w) not in self.newly_arrived_entities and
                w not in self.collaboration_waiting['workers'] and
                self.worker_availability.get(w, True) and
                self._is_entity_online('worker', w))
        ]

        # 获取未完成任务
        unfinished_tasks = [
            t for t in self.positions['tasks']
            if self.task_status.get(t) == '未完成' and not self.task_assignment.get(t, False)
        ]

        if not unfinished_tasks:
            # 没有任务，让满载的无人机去数据中心
            for drone_id in available_drones:
                if self.drone_capacity[drone_id]['current'] > 0:
                    dc_pos, _ = self._closest_data_center(self.positions['drones'][drone_id])
                    if self._can_reach_in_available_time('drones', drone_id, dc_pos):
                        weight = self._calculate_weight('drone_to_dc', drone_id=drone_id)
                        scheduled_actions.append({
                            'type': 'drone_to_dc',
                            'drone_id': drone_id,
                            'target': dc_pos,
                            'weight': weight
                        })
                        assigned_drones.add(drone_id)
            return scheduled_actions

        # 第一步：寻找协作任务机会（使用原权重公式）
        candidate_actions = []

        for drone_id in available_drones:
            drone_cap = self.drone_capacity[drone_id]
            if drone_cap['current'] >= drone_cap['full']:
                continue  # 无人机已满

            for worker_id in available_workers:
                for task_id in unfinished_tasks:
                    # 检查是否可以在在线时间内完成
                    if not self._can_complete_in_time(drone_id, worker_id, task_id):
                        continue

                    # 检查容量
                    task_data = self.task_data[task_id]
                    if task_data > (drone_cap['full'] - drone_cap['current']):
                        continue

                    # 检查是否能到达
                    task_pos = self.positions['tasks'][task_id]
                    if not (self._can_reach_in_available_time('drones', drone_id, task_pos) and
                            self._can_reach_in_available_time('workers', worker_id, task_pos)):
                        continue

                    # 检查卸载可行性
                    if not self._can_unload_after_task(drone_id, worker_id, task_id):
                        continue

                    # 计算权重（使用原公式）
                    weight = self._calculate_weight('collaborate',
                                                    drone_id=drone_id,
                                                    worker_id=worker_id,
                                                    task_id=task_id)
                    candidate_actions.append({
                        'type': 'collaborate',
                        'drone_id': drone_id,
                        'worker_id': worker_id,
                        'task_id': task_id,
                        'weight': weight
                    })

        # 按权重排序并选择（权重高的优先）
        candidate_actions.sort(key=lambda x: x['weight'], reverse=True)

        for action in candidate_actions:
            if (action['drone_id'] not in assigned_drones and
                    action['worker_id'] not in assigned_workers and
                    action['task_id'] not in assigned_tasks):
                scheduled_actions.append(action)
                assigned_drones.add(action['drone_id'])
                assigned_workers.add(action['worker_id'])
                assigned_tasks.add(action['task_id'])
                self.task_assignment[action['task_id']] = True

        # 第二步：无人机去数据中心卸载（如果有数据）
        for drone_id in available_drones:
            if drone_id in assigned_drones:
                continue

            if self.drone_capacity[drone_id]['current'] > 0:
                dc_pos, _ = self._closest_data_center(self.positions['drones'][drone_id])
                if self._can_reach_in_available_time('drones', drone_id, dc_pos):
                    weight = self._calculate_weight('drone_to_dc', drone_id=drone_id)
                    scheduled_actions.append({
                        'type': 'drone_to_dc',
                        'drone_id': drone_id,
                        'target': dc_pos,
                        'weight': weight
                    })
                    assigned_drones.add(drone_id)

        # 注意：原算法中 UiTx 和 WjTx 的权重为0，所以贪心算法也不考虑这些动作
        # 这样可以保持与原算法完全相同的权重评估标准

        return scheduled_actions

    def _can_complete_in_time(self, drone_id, worker_id, task_id):
        """检查是否能在在线时间内完成任务"""
        drone_downtime = self.drone_capacity[drone_id].get('downtime', self.time_steps)
        worker_downtime = self.worker_info[worker_id].get('downtime', self.time_steps)

        # 简单估计：当前时间 + 最大移动时间 + 1步执行时间
        task_pos = self.positions['tasks'][task_id]

        drone_pos = self.positions['drones'][drone_id]
        drone_dist = self._dist(drone_pos, task_pos)
        drone_time = max(1, math.ceil(drone_dist / self.mobility_radii['drones'][drone_id]))

        worker_pos = self.positions['workers'][worker_id]
        worker_dist = self._dist(worker_pos, task_pos)
        worker_time = max(1, math.ceil(worker_dist / self.mobility_radii['workers'][worker_id]))

        completion_time = self.current_time_step + max(drone_time, worker_time) + 1

        return completion_time <= min(drone_downtime, worker_downtime)

    def _can_unload_after_task(self, drone_id, worker_id, task_id):
        """检查无人机在协作任务完成后是否有足够时间移动到数据中心卸载数据"""
        task_pos = self.positions['tasks'][task_id]

        # 计算到达任务点的时间
        drone_pos = self.positions['drones'][drone_id]
        drone_dist = self._dist(drone_pos, task_pos)
        drone_time = max(1, math.ceil(drone_dist / self.mobility_radii['drones'][drone_id]))

        worker_pos = self.positions['workers'][worker_id]
        worker_dist = self._dist(worker_pos, task_pos)
        worker_time = max(1, math.ceil(worker_dist / self.mobility_radii['workers'][worker_id]))

        arrival_time = self.current_time_step + max(drone_time, worker_time)

        # 计算从任务点到数据中心的时间
        dc_pos, dc_dist = self._closest_data_center(task_pos)
        dc_time = max(1, math.ceil(dc_dist / self.mobility_radii['drones'][drone_id]))

        completion_time = arrival_time + dc_time + 1

        drone_downtime = self.drone_capacity[drone_id].get('downtime', self.time_steps)
        simulation_end = self.time_steps

        return completion_time <= min(drone_downtime, simulation_end)

    def _execute_actions(self, actions):
        """执行调度动作"""
        update_details = {
            'tasks_completed': [],
            'data_collected': 0,
            'positions_changed': []
        }

        for action in actions:
            if action['type'] == 'collaborate':
                drone_id = action['drone_id']
                worker_id = action['worker_id']
                task_id = action['task_id']
                task_pos = self.positions['tasks'][task_id]

                # 记录协作状态
                self.collaboration_status[task_id] = {
                    'drone_id': drone_id,
                    'worker_id': worker_id,
                    'drone_arrived': False,
                    'worker_arrived': False
                }

                # 调度无人机
                drone_pos = self.positions['drones'][drone_id]
                if self._dist(drone_pos, task_pos) <= self.mobility_radii['drones'][drone_id]:
                    self.positions['drones'][drone_id] = task_pos
                    self.collaboration_status[task_id]['drone_arrived'] = True
                    self.movement_history['drones'][drone_id].append(
                        (self.current_time_step, f"协作任务: 到达任务点 {task_id}", task_pos)
                    )
                else:
                    self.moving_entities['drones'][drone_id] = {
                        'target': task_pos,
                        'action': f"协作任务: 移动至任务点 {task_id}",
                        'destination_type': 'task'
                    }

                # 调度工人
                worker_pos = self.positions['workers'][worker_id]
                if self._dist(worker_pos, task_pos) <= self.mobility_radii['workers'][worker_id]:
                    self.positions['workers'][worker_id] = task_pos
                    self.worker_availability[worker_id] = False
                    self.collaboration_status[task_id]['worker_arrived'] = True
                    self.movement_history['workers'][worker_id].append(
                        (self.current_time_step, f"协作任务: 到达任务点 {task_id}", task_pos)
                    )
                else:
                    self.moving_entities['workers'][worker_id] = {
                        'target': task_pos,
                        'action': f"协作任务: 移动至任务点 {task_id}"
                    }
                    self.worker_availability[worker_id] = False

                update_details['positions_changed'].append(
                    f"无人机 {drone_id} 和工人 {worker_id} 开始向任务点 {task_id} 移动"
                )

            elif action['type'] == 'drone_to_dc':
                drone_id = action['drone_id']
                dc_pos = action['target']

                drone_pos = self.positions['drones'][drone_id]
                if self._dist(drone_pos, dc_pos) <= self.mobility_radii['drones'][drone_id]:
                    self.positions['drones'][drone_id] = dc_pos
                    # 卸载数据
                    if self.drone_capacity[drone_id]['current'] > 0:
                        data_offloaded = self.drone_capacity[drone_id]['current']
                        self.data_offloaded += data_offloaded
                        self.drone_capacity[drone_id]['current'] = 0
                    self.movement_history['drones'][drone_id].append(
                        (self.current_time_step, "到达数据中心并卸载", dc_pos)
                    )
                else:
                    self.moving_entities['drones'][drone_id] = {
                        'target': dc_pos,
                        'action': "移动至数据中心",
                        'destination_type': 'data_center'
                    }

                update_details['positions_changed'].append(f"无人机 {drone_id} 开始向数据中心移动")

        # 检查协作任务完成情况
        self._check_collaboration_completion()

        # 恢复空闲工人的可用性
        for worker_id in self.worker_availability:
            if worker_id not in self.moving_entities['workers']:
                self.worker_availability[worker_id] = True

        return update_details

    def schedule(self, time_step):
        """执行单个时间步的调度"""
        self.current_time_step = time_step

        # 更新移动中的实体
        self._update_moving_entities()

        # 检查协作任务完成情况
        self._check_collaboration_completion()

        # 简化贪心调度
        actions = self._simple_greedy_schedule()

        # 执行动作
        update_details = self._execute_actions(actions)

        # 记录结果
        step_result = {
            'time_step': time_step,
            'actions': actions,
            'tasks_completed': update_details['tasks_completed'],
            'data_collected': update_details['data_collected'],
            'remaining_tasks': sum(1 for status in self.task_status.values() if status == '未完成'),
            'total_data_offloaded': self.data_offloaded,
            'total_weight': sum(action.get('weight', 0) for action in actions)
        }

        self.simulation_results.append(step_result)

        # 最后一个时间步强制卸载
        if time_step == self.time_steps:
            self._force_unload()

        return actions

    def _force_unload(self):
        """强制卸载所有无人机数据"""
        for drone_id in self.positions['drones']:
            if self.drone_capacity[drone_id]['current'] > 0:
                dc_pos, _ = self._closest_data_center(self.positions['drones'][drone_id])
                self.positions['drones'][drone_id] = dc_pos
                data_offloaded = self.drone_capacity[drone_id]['current']
                self.data_offloaded += data_offloaded
                self.drone_capacity[drone_id]['current'] = 0
                self.movement_history['drones'][drone_id].append(
                    (self.current_time_step, "强制移动到数据中心并卸载", dc_pos)
                )

    def run_simulation(self):
        """运行多时刻模拟"""
        start_time = datetime.now()

        # 运行每个时间步
        for t in range(1, self.time_steps + 1):
            self.schedule(t)

        end_time = datetime.now()
        elapsed_time = end_time - start_time

        # 输出最终结果
        self._print_final_results(elapsed_time)

        return self.simulation_results

    def _print_final_results(self, elapsed_time):
        """打印最终模拟结果"""
        print("=" * 80)
        print("=== 简化贪心算法模拟最终结果（使用原权重公式）===")
        print("=" * 80)
        print()

        # 计算任务完成率
        total_tasks = len(self.task_status)
        completed_tasks = sum(1 for status in self.task_status.values() if status == '已完成')
        completion_rate = (completed_tasks / total_tasks) * 100 if total_tasks > 0 else 0

        # 计算总权重
        total_weight = sum(result.get('total_weight', 0) for result in self.simulation_results)

        print(f"任务完成率: {completion_rate:.2f}% ({completed_tasks}/{total_tasks})")
        print(f"模拟运行时间: {elapsed_time.total_seconds():.3f} 秒")
        print(f"总卸载数据量: {self.data_offloaded:.1f}")
        print(f"累计权重: {total_weight:.4f}")
        print()

        # 时间步摘要
        print("时间步 | 调度动作数 | 累计权重 | 完成任务 | 收集数据 | 卸载数据 | 剩余任务")
        print("------|-----------|----------|---------|----------|----------|--------")
        for result in self.simulation_results:
            ts = result['time_step']
            action_count = len(result['actions'])
            weight = result.get('total_weight', 0)
            tasks_completed = len(result['tasks_completed'])
            data_collected = result['data_collected']
            data_offloaded = result.get('total_data_offloaded', 0)
            remaining_tasks = result['remaining_tasks']

            print(
                f"{ts:5} | {action_count:10} | {weight:8.4f} | {tasks_completed:7} | {data_collected:8.1f} | {data_offloaded:8.1f} | {remaining_tasks:7}")

        print()
        print("=" * 80)

# Tool.py (修正版)
import numpy as np
import math

# 全局变量
total_unload_opportunities = 0
successful_unloads = 0


def reset_unload_stats():
    global total_unload_opportunities, successful_unloads
    total_unload_opportunities = 0
    successful_unloads = 0


def s_obs_avail_action(Env, Agent_Sign, Action_Dim, Agent_Loc, Memory, DataConsum, Agent_Online,
                       UAV_Fullm, CurrTime, TimeLimit, datacenter_positions, worker_count):
    """
    生成状态、观察和可用动作

    新增参数:
    - UAV_Fullm: 无人机最大存储容量
    - datacenter_positions: 数据中心位置列表
    - worker_count: 工人数量，用于计算无人机索引
    """
    Row = Env.shape[1]
    Lin = Env.shape[2]
    Agent_Num = Agent_Sign.shape[0]

    # 计算无人机数量
    uav_count = Agent_Num - worker_count

    # ✅ 状态通道变为 6：障碍、任务点、数据中心、用户位置、无人机位置、无人机紧迫性
    s = np.zeros((6, Row, Lin))
    s[0, :, :] = Env[0, :, :]  # 通道0: 障碍物 (全部为0)
    s[1, :, :] = Env[1, :, :]  # 通道1: 任务点
    s[2, :, :] = Env[2, :, :]  # 通道2: 数据中心位置（多个）

    for i in range(Agent_Num):
        # 检查智能体是否在线
        online_time = Agent_Online[i, 0]
        offline_time = min(Agent_Online[i, 1], TimeLimit)

        if CurrTime < online_time or CurrTime > offline_time:
            continue  # 智能体不在线，跳过

        if Agent_Sign[i] == 1:  # 工人
            s[3, :, :] += Agent_Loc[i, :, :]  # 第 3 层：工人位置
        elif Agent_Sign[i] == 3:  # 无人机
            s[4, :, :] += Agent_Loc[i, :, :]  # 第 4 层：无人机位置
            # 计算紧迫性：基于存储使用率
            # 计算无人机在UAV_Fullm中的索引
            if i >= worker_count:  # 确保是无人机
                uav_idx = i - worker_count
                if uav_idx < len(UAV_Fullm):
                    full_memory = UAV_Fullm[uav_idx]
                    current_memory = Memory[i]
                    if full_memory > 0:
                        usage_ratio = current_memory / full_memory
                        urgency = 10 * usage_ratio  # 使用率越高，紧迫性越高
                    else:
                        urgency = 0
                else:
                    urgency = 0

                # 找到无人机位置
                for ii in range(Row):
                    for jj in range(Lin):
                        if Agent_Loc[i, ii, jj] == 1:
                            s[5, ii, jj] += urgency  # 第 5 层：无人机紧迫性
                            break
                    else:
                        continue
                    break

    # 扁平化全局状态向量
    s = s.flatten()

    # 动作空间生成
    avail_action = []
    obs = []

    for i in range(Agent_Num):
        # 检查智能体是否在线
        online_time = Agent_Online[i, 0]
        offline_time = min(Agent_Online[i, 1], TimeLimit)

        # 定位当前智能体位置
        current_row, current_col = np.where(Agent_Loc[i] == 1)
        if len(current_row) == 0:
            continue  # 处理无效位置
        ii, jj = current_row[0], current_col[0]

        temp_avail_action = np.zeros((Row, Lin))

        # 如果智能体不在线，只能原地不动
        if CurrTime < online_time or CurrTime > offline_time:
            temp_avail_action[ii, jj] = 1
        elif Agent_Sign[i] == 3:  # 无人机
            # 检查无人机存储是否已满
            if i >= worker_count:  # 确保是无人机
                uav_idx = i - worker_count
                if uav_idx < len(UAV_Fullm) and Memory[i] >= UAV_Fullm[uav_idx]:
                    temp_avail_action[ii, jj] = 1  # 存储满时停留
                else:
                    # 正常移动逻辑
                    radius = Action_Dim[i, 0]
                    generate_movement_mask(temp_avail_action, ii, jj, radius, Row, Lin, Env)
        else:  # 工人或其他智能体
            # 正常移动逻辑
            radius = Action_Dim[i, 0]
            generate_movement_mask(temp_avail_action, ii, jj, radius, Row, Lin, Env)

        # 展平并拼接动作空间
        temp_avail_action = temp_avail_action.flatten()
        avail_action = np.concatenate((avail_action, temp_avail_action), 0)

        # 局部观察：位置标记
        Agent_Loc_Temp = Agent_Loc[i, :, :].flatten()
        obs = np.concatenate((obs, Agent_Loc_Temp), 0)

        # 智能体身份（one-hot）
        Agent_Sign_temp = np.zeros(Agent_Num)
        Agent_Sign_temp[i] = 1
        obs = np.concatenate((obs, Agent_Sign_temp), 0)

        # 智能体类型 + 存储紧迫性
        if Agent_Sign[i] == 1:  # 工人
            obs = np.concatenate((obs, [1, 0]), 0)
            obs = np.concatenate((obs, [0]), 0)
        elif Agent_Sign[i] == 3:  # 无人机
            obs = np.concatenate((obs, [0, 1]), 0)
            # 计算存储紧迫性
            if i >= worker_count:  # 确保是无人机
                uav_idx = i - worker_count
                if uav_idx < len(UAV_Fullm):
                    full_memory = UAV_Fullm[uav_idx]
                    current_memory = Memory[i]
                    if full_memory > 0:
                        urgency = 10 * (current_memory / full_memory)
                    else:
                        urgency = 0
                else:
                    urgency = 0
            else:
                urgency = 0
            obs = np.concatenate((obs, [urgency]), 0)

    return s, obs, avail_action


def generate_movement_mask(mask, center_x, center_y, radius, rows, cols, Env):
    """生成移动掩码的辅助函数"""
    min_x = max(0, math.floor(center_x - radius))
    max_x = min(rows, math.ceil(center_x + radius) + 1)
    min_y = max(0, math.floor(center_y - radius))
    max_y = min(cols, math.ceil(center_y + radius) + 1)

    for x in range(min_x, max_x):
        for y in range(min_y, max_y):
            dx = x - center_x
            dy = y - center_y
            # 欧氏距离检查
            if math.sqrt(dx ** 2 + dy ** 2) <= radius:
                # 障碍物检查（现在全部为0可通行）
                if Env[0, x, y] == 0:
                    mask[x, y] = 1


def Update_Agent_Loc(
        Env, Agent_Sign, Memory, DataConsum, action, Agent_Online, UAV_Fullm,
        task_cost_dict, datacenter_positions, CurrTime, TimeLimit,
        UploadCooldown, Data_Collected, current_Agent_Loc, worker_count
):
    """
    更新智能体位置并处理任务完成和数据卸载

    新增参数:
    - UAV_Fullm: 无人机最大存储容量
    - task_cost_dict: 任务消耗字典 {(x,y): cost}
    - datacenter_positions: 数据中心位置列表
    - worker_count: 工人数量
    """
    Row = Env.shape[1]
    Lin = Env.shape[2]
    Agent_Num = Agent_Sign.shape[0]
    Agent_Loc_new = np.copy(current_Agent_Loc)

    # 更新位置信息
    for Agent_Index in range(Agent_Num):
        # 检查智能体是否在线
        online_time = Agent_Online[Agent_Index, 0]
        offline_time = min(Agent_Online[Agent_Index, 1], TimeLimit)

        # 如果智能体不在线，保持原位置
        if CurrTime < online_time or CurrTime > offline_time:
            continue

        # 清空当前位置
        Agent_Loc_new[Agent_Index, :, :] = 0

        # 计算新位置
        Agent_Row = int(action[Agent_Index] / Lin)
        Agent_Lin = int(action[Agent_Index] % Lin)
        Agent_Loc_new[Agent_Index, Agent_Row, Agent_Lin] = 1

    r = 0
    task_complete_count = 0
    total_unload_opportunities = 0
    successful_unloads = 0
    total_data_unloaded = 0

    # 处理任务完成
    for i in range(Row):
        for j in range(Lin):
            if Env[1, i, j] == 1:  # 有任务
                worker_present = False
                uav_here = []

                for idx in range(Agent_Num):
                    # 检查在线状态
                    online_time = Agent_Online[idx, 0]
                    offline_time = min(Agent_Online[idx, 1], TimeLimit)

                    if CurrTime < online_time or CurrTime > offline_time:
                        continue

                    if Agent_Loc_new[idx, i, j] == 1:
                        if Agent_Sign[idx] == 1:  # 工人
                            worker_present = True
                        elif Agent_Sign[idx] == 3:  # 无人机
                            uav_idx_in_array = idx - worker_count
                            if uav_idx_in_array < len(UAV_Fullm):
                                # 检查是否有足够容量
                                task_cost = task_cost_dict.get((i, j), DataConsum[idx])
                                if Memory[idx] + task_cost <= UAV_Fullm[uav_idx_in_array]:
                                    uav_here.append(idx)

                if worker_present and len(uav_here) > 0:
                    chosen_idx = uav_here[0]
                    uav_idx = chosen_idx - worker_count
                    task_cost = task_cost_dict.get((i, j), DataConsum[chosen_idx])

                    # 完成任务
                    Env[1, i, j] = 0
                    r += 1
                    task_complete_count += 1

                    # 无人机收集数据（存储增加）
                    Memory[chosen_idx] += task_cost
                    Data_Collected[chosen_idx] = True

                    #print(f"✅ 任务完成 at ({i}, {j}) by UAV {chosen_idx}")

    # 处理数据卸载
    for dc_x, dc_y in datacenter_positions:
        for idx in range(Agent_Num):
            if Agent_Sign[idx] != 3:  # 只处理无人机
                continue

            # 检查在线状态
            online_time = Agent_Online[idx, 0]
            offline_time = min(Agent_Online[idx, 1], TimeLimit)

            if CurrTime < online_time or CurrTime > offline_time:
                continue

            if Agent_Loc_new[idx, dc_x, dc_y] == 1:
                total_unload_opportunities += 1

                uav_idx = idx - worker_count

                # 检查是否可以卸载
                if (Data_Collected[idx] and
                        uav_idx < len(UAV_Fullm) and
                        Memory[idx] > 0 and
                        not UploadCooldown[idx]):

                    successful_unloads += 1

                    # 计算卸载数据量和奖励
                    uploaded_data = float(Memory[idx])
                    total_data_unloaded += uploaded_data

                    base_reward = 2.5
                    if UAV_Fullm[uav_idx] > 0:
                        unload_reward = base_reward * (uploaded_data / UAV_Fullm[uav_idx])
                    else:
                        unload_reward = base_reward * (uploaded_data / 100.0)

                    unload_reward = max(unload_reward, 0.5)
                    r += unload_reward

                    # 清空存储
                    Memory[idx] = 0
                    Data_Collected[idx] = False
                    UploadCooldown[idx] = True

                    #print(f"📦 数据卸载: UAV {idx} at ({dc_x}, {dc_y})")

    # 冷却解除
    for idx in range(Agent_Num):
        if Agent_Sign[idx] != 3:  # 只处理无人机
            continue

        # 检查智能体是否在线
        online_time = Agent_Online[idx, 0]
        offline_time = min(Agent_Online[idx, 1], TimeLimit)

        if CurrTime < online_time or CurrTime > offline_time:
            continue

        if UploadCooldown[idx]:
            # 获取当前位置
            i, j = np.where(Agent_Loc_new[idx] == 1)
            if i.size > 0:
                ii, jj = i[0], j[0]
                # 如果不在数据中心，解除冷却
                if not any([ii == dc_x and jj == dc_y for dc_x, dc_y in datacenter_positions]):
                    UploadCooldown[idx] = False

    # ✅ 返回所有更新后的数据
    return (
        Env, Agent_Loc_new, Memory, r,
        task_complete_count, UploadCooldown,
        Data_Collected, total_unload_opportunities,
        successful_unloads, total_data_unloaded
    )
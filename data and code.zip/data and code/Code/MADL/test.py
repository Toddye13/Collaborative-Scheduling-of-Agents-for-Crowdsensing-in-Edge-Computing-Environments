# test.py (修正版)
import numpy as np
from Tool import s_obs_avail_action, Update_Agent_Loc


def Test_Func(Data, qmix_algo, TimeLimit, UAV_Fullm=None, task_cost_dict=None,
              datacenter_positions=None, worker_count=None):
    """
    测试函数，支持新数据结构

    参数:
    - Data: 数据字典
    - qmix_algo: QMix算法实例
    - TimeLimit: 时间限制
    - UAV_Fullm: 无人机最大容量数组
    - task_cost_dict: 任务消耗字典
    - datacenter_positions: 数据中心位置列表
    - worker_count: 工人数量
    """

    # 如果没有提供新参数，尝试从Data中获取
    if UAV_Fullm is None and 'UAV_Fullm' in Data:
        UAV_Fullm = Data['UAV_Fullm']
    if task_cost_dict is None and 'task_cost_dict' in Data:
        task_cost_dict = Data['task_cost_dict']
    if datacenter_positions is None and 'datacenter_positions' in Data:
        datacenter_positions = Data['datacenter_positions']
    if worker_count is None and 'worker_count' in Data:
        worker_count = Data['worker_count']

    # 复制环境数据
    Env_ = np.copy(Data['Env'])
    Agent_Sign_ = np.copy(Data['Agent_Sign'])
    Action_Dim_ = np.copy(Data['Action_Dim'])
    Agent_Loc_ = np.copy(Data['Agent_Loc'])
    Memory_ = np.copy(Data['Memory'])
    DataConsum_ = np.copy(Data['DataConsum'])
    Agent_Online_ = np.copy(Data['Agent_Online'])

    # 初始化
    s, obs, avail_action = s_obs_avail_action(
        Env_, Agent_Sign_, Action_Dim_, Agent_Loc_, Memory_, DataConsum_,
        Agent_Online_, UAV_Fullm, 0, TimeLimit, datacenter_positions, worker_count
    )

    CurrTime = 0
    Data_Collected = [False for _ in range(len(Agent_Sign_))]
    UploadCooldown = [False for _ in range(len(Agent_Sign_))]

    AllTask = np.sum(Env_[1, :, :])
    ComplateTask = 0
    unload_curve = np.zeros((TimeLimit,))

    while CurrTime < TimeLimit:
        CurrTime += 1

        # 选择动作
        action = qmix_algo.choose_action(s, obs, avail_action)

        # 更新环境
        Env_, Agent_Loc_, Memory_, r, task_completed, UploadCooldown, Data_Collected, \
            unload_opp, successful, step_data_unloaded = \
            Update_Agent_Loc(
                Env_, Agent_Sign_, Memory_, DataConsum_, action, Agent_Online_,
                UAV_Fullm, task_cost_dict, datacenter_positions, CurrTime, TimeLimit,
                UploadCooldown, Data_Collected, Agent_Loc_, worker_count
            )

        ComplateTask += task_completed
        unload_curve[CurrTime - 1] = step_data_unloaded

        # 获取下一状态
        s_next, obs_next, avail_action_next = s_obs_avail_action(
            Env_, Agent_Sign_, Action_Dim_, Agent_Loc_, Memory_, DataConsum_,
            Agent_Online_, UAV_Fullm, CurrTime, TimeLimit, datacenter_positions, worker_count
        )

        # 更新状态
        s = np.copy(s_next)
        obs = np.copy(obs_next)
        avail_action = np.copy(avail_action_next)

    return AllTask, ComplateTask, unload_curve
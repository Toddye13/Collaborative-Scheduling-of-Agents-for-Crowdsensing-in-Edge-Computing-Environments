import CNN
import rnn_agent
import qmixer
import torch
import numpy as np

use_cuda = torch.cuda.is_available()
device = torch.device("cuda:0" if use_cuda else "cpu")


class QMix:
    def __init__(self, learning_rate, reward_decay, INITIAL_EPSILON, FINAL_EPSILON, memory_size, batch_size,
                 update_target_network, agent_Num, row, lin):
        self.learning_rate = learning_rate
        self.reward_decay = reward_decay
        self.INITIAL_EPSILON = INITIAL_EPSILON
        self.FINAL_EPSILON = FINAL_EPSILON
        self.memory_size = memory_size
        self.batch_size = batch_size
        self.update_target_network = update_target_network

        # 智能体数量，包括参与者、补给小车、无人机
        self.agent_Num = agent_Num
        # 空间区域为矩形，边的宽和长为 row 和 lin
        self.row = row
        self.lin = lin
        # 全局观察 size，全局观察为 6 通道，障碍物、任务点、参与者、补给小车、无人机、数据卸载中心
        self.Global_Obs = 6 * self.row * self.lin
        # 智能体位置标识，智能体 ID 编号，智能体类型标识
        self.Local_Obs = self.row * self.lin + self.agent_Num + 2 + 1
        # 矩形区域内的位置点均可移动
        self.agent_actions = self.row * self.lin

        # 输入张量的通道数
        self.in_channels = 6
        # 输出张量的通道数
        self.out_channels = 10
        # 卷积核的大小，一般我们会使用 5x5、3x3 这种左右两个数相同的卷积核
        self.kernel_size = 3
        # 卷积核在图像窗口上每次平移的间隔，即所谓的步长
        self.stride = 1
        # Padding 即所谓的图像填充，以 padding = 1 为例，
        # 若原始图像大小为 32x32，那么 padding 后的图像大小就变成了 34x34，而不是 33x33
        self.padding = 1
        # 这个参数决定了是否采用空洞卷积，默认为 1（不采用）
        self.dilation = 1
        # 池化窗口
        self.Pool_size = 2

        # 全局观察 size，全局观察为 6 通道，障碍物、任务点、参与者、补给小车、无人机、数据卸载中心
        self.Global_Obs = 6 * self.row * self.lin

        # 实例化卷积网络
        self.CNN_space = CNN.cnn(self.in_channels, self.out_channels, self.kernel_size, self.stride, self.padding,
                                 self.dilation, self.Pool_size).to(device)
        self.CNN_space_target = CNN.cnn(self.in_channels, self.out_channels, self.kernel_size, self.stride,
                                        self.padding,
                                        self.dilation, self.Pool_size).to(device)

        # 计算实际的全局特征维度
        with torch.no_grad():
            test_input = torch.zeros(1, self.in_channels, self.row, self.lin).to(device)
            test_output = self.CNN_space(test_input)
            self.Global_features = test_output.numel()  # 使用实际输出的大小

        #self.Global_features = int(self.row * self.lin * self.out_channels / (self.Pool_size ** 2))
        self.agent_features = self.Global_features + self.Local_Obs

        # 实例化智能体网络
        self.agents = rnn_agent.RNNAgent(self.agent_features, self.agent_features * 10, self.agent_actions).to(device)
        self.target_agents = rnn_agent.RNNAgent(self.agent_features, self.agent_features * 10,
                                                self.agent_actions).to(device)

        # 实例化混合网络
        self.qmixer = qmixer.QMixer(self.agent_Num, self.Global_features, self.agent_Num * 10,
                                    self.Global_features * 10).to(device)
        self.target_qmixer = qmixer.QMixer(self.agent_Num, self.Global_features, self.agent_Num * 10,
                                           self.Global_features * 10).to(device)

        # 目标网络赋值
        self.CNN_space_target.update(self.CNN_space)
        self.target_agents.update(self.agents)
        self.target_qmixer.update(self.qmixer)

        # 构建参数列表，其中包含卷积层参数、智能体参数和混合网络参数
        self.params = list(self.CNN_space.parameters())
        self.params += list(self.agents.parameters())
        self.params += list(self.qmixer.parameters())

        self.optimizer = torch.optim.RMSprop(params=self.params, lr=self.learning_rate, alpha=0.99, eps=0.00001)
        # 总的学习次数 计数器
        self.learn_step_counter = 0

        # 初始化记忆 [s, s_next, obs, obs_next, avail_action, avail_action_next, a, r, t, ]
        self.memoryDim = self.Global_Obs * 2 + (self.Local_Obs + self.agent_actions) * self.agent_Num * 2 + self.agent_Num + 2
        # 初始化经验池
        self.memory = np.zeros((self.memory_size, self.memoryDim))
        # 记录 loss 的变化列表
        self.loss_his = []

    def save_model(self, filename_CNN, filename_agent, filename_qmixer):
        torch.save(self.CNN_space.state_dict(), filename_CNN)
        torch.save(self.agents.state_dict(), filename_agent)
        torch.save(self.qmixer.state_dict(), filename_qmixer)

    def load_model(self, filename_CNN, filename_agent, filename_qmixer):
        self.CNN_space.load_state_dict(torch.load(filename_CNN))
        self.CNN_space.eval()
        self.agents.load_state_dict(torch.load(filename_agent))
        self.agents.eval()
        self.qmixer.load_state_dict(torch.load(filename_qmixer))
        self.qmixer.eval()

    # 存储经验池的函数
    def store_transition(self, s, s_next, obs, obs_next, avail_action, avail_action_next, a, r, t):
        # 如果没有 'memory_counter' 这个变量，就创建为 0
        if not hasattr(self, 'memory_counter'):
            self.memory_counter = 0
        # 每条经验的存放形式
        transition = np.hstack((s, s_next, obs, obs_next, avail_action, avail_action_next, a, r, t))
        # 用新经验取代旧经验，循环列表，装满了就取代最久远的
        index = self.memory_counter % self.memory_size
        self.memory[index, :] = transition
        self.memory_counter = self.memory_counter + 1

    # 输入的是智能体的观测值和可执行行为集合
    def choose_action(self, s, observation, Curr_avail_action):
        action = np.zeros((self.agent_Num))  # 初始化联合行为矩阵
        # e-GREEDY 算法判断是否随机
        if np.random.uniform() > self.INITIAL_EPSILON:
            # 先计算当前空间信息的卷积结果
            s_batch_Cov = s.reshape(1, 6, self.row, self.lin)
            s_batch_Cov = torch.tensor(s_batch_Cov, dtype=torch.float).to(device)
            Cov_output = self.CNN_space(s_batch_Cov)
            output = Cov_output.view(-1)  # 展平为一维向量

            for agent_idx in range(self.agent_Num):
                # 取出智能体 agent_idx 的局部观察，以计算当前局部观察所对应的 q-value
                Dim_Start = self.Local_Obs * agent_idx
                Dim_End = self.Local_Obs * (agent_idx + 1)
                temp_observation = observation[Dim_Start:Dim_End]
                temp_observation = torch.tensor(temp_observation, dtype=torch.float).to(device)

                # 确保 output 和 temp_observation 的维度匹配
                if output.size(0) != self.Global_features:
                    # 如果维度不匹配，调整 output 的大小
                    output_resized = output[:self.Global_features]  # 截取前 Global_features 个元素
                    temp_observation = torch.cat((output_resized, temp_observation), dim=0)
                else:
                    temp_observation = torch.cat((output, temp_observation), dim=0)

                q_eval_agent = self.agents(temp_observation)

                # 取出不能选择的区域标识
                Dim_Start = self.agent_actions * agent_idx
                Dim_End = self.agent_actions * (agent_idx + 1)
                temp_avail_action = Curr_avail_action[Dim_Start:Dim_End]

                temp_avail_action = torch.tensor(temp_avail_action, dtype=torch.float).to(device)
                q_eval_agent[temp_avail_action == 0.0] = -9999999
                action[agent_idx] = torch.argmax(q_eval_agent)  # 返回 Q 值最大的动作索引值，是从 0 开始到 n_action-1！
        else:
            for agent_idx in range(self.agent_Num):
                # 取出不能选择的区域标识
                Dim_Start = self.agent_actions * agent_idx
                Dim_End = self.agent_actions * (agent_idx + 1)
                temp_avail_action = Curr_avail_action[Dim_Start:Dim_End]
                # 需要将 tuple 转换成 ndarray 类型
                Curr_avail_action_idx = np.nonzero(temp_avail_action)[0]
                action[agent_idx] = np.random.choice(Curr_avail_action_idx)

        return action

    def max_action(self, s, observation, Curr_avail_action):
        # 先计算当前空间信息的卷积结果
        s_batch_Cov = s.reshape(1, 6, self.row, self.lin)
        s_batch_Cov = torch.tensor(s_batch_Cov, dtype=torch.float).to(device)
        Cov_output = self.CNN_space(s_batch_Cov)

        # 使用实际大小而不是预计算的大小
        output = Cov_output.view(-1)  # 展平为一维向量

        action = np.zeros((self.agent_Num))  # 初始化联合行为矩阵

        for agent_idx in range(self.agent_Num):
            # 取出智能体 agent_idx 的局部观察，以计算当前局部观察所对应的 q-value
            Dim_Start = self.Local_Obs * agent_idx
            Dim_End = self.Local_Obs * (agent_idx + 1)
            temp_observation = observation[Dim_Start:Dim_End]
            temp_observation = torch.tensor(temp_observation, dtype=torch.float).to(device)

            # 确保 output 和 temp_observation 的维度匹配
            if output.size(0) != self.Global_features:
                # 如果维度不匹配，调整 output 的大小
                output_resized = output[:self.Global_features]  # 截取前 Global_features 个元素
                temp_observation = torch.cat((output_resized, temp_observation), dim=0)
            else:
                temp_observation = torch.cat((output, temp_observation), dim=0)

            # 取出不能选择的区域标识
            Dim_Start = self.agent_actions * agent_idx
            Dim_End = self.agent_actions * (agent_idx + 1)
            temp_avail_action = Curr_avail_action[Dim_Start:Dim_End]

            # 选出最优区域
            q_eval_agent = self.agents(temp_observation)
            temp_avail_action = torch.tensor(temp_avail_action, dtype=torch.float).to(device)
            q_eval_agent[temp_avail_action == 0.0] = -9999999
            action[agent_idx] = torch.argmax(q_eval_agent)  # 返回 Q 值最大的动作索引值，是从 0 开始到 n_action-1！

        return action

    def learn(self):
        sample_index = np.random.choice(self.memory_size, size=self.batch_size, replace=False)
        batch_memory = self.memory[sample_index, :]  # 拿出索引训练数据

        # 提取经验池各项数据
        Dim_Start = 0
        Dim_End = self.Global_Obs
        s_batch = batch_memory[:, Dim_Start:Dim_End]
        Dim_Start = Dim_End
        Dim_End += self.Global_Obs
        s_next_batch = batch_memory[:, Dim_Start:Dim_End]
        Dim_Start = Dim_End
        Dim_End += self.Local_Obs * self.agent_Num
        obs_batch = batch_memory[:, Dim_Start:Dim_End]
        Dim_Start = Dim_End
        Dim_End += self.Local_Obs * self.agent_Num
        obs_next_batch = batch_memory[:, Dim_Start:Dim_End]
        Dim_Start = Dim_End
        Dim_End += self.agent_actions * self.agent_Num
        avail_action_batch = batch_memory[:, Dim_Start:Dim_End]
        Dim_Start = Dim_End
        Dim_End += self.agent_actions * self.agent_Num
        avail_action_next_batch = batch_memory[:, Dim_Start:Dim_End]
        Dim_Start = Dim_End
        Dim_End += self.agent_Num
        a_batch = batch_memory[:, Dim_Start:Dim_End]
        r_batch = batch_memory[:, Dim_End]
        t_batch = batch_memory[:, Dim_End + 1]

        # 当前状态卷积编码
        s_batch_Cov = s_batch.reshape(self.batch_size, 6, self.row, self.lin)
        s_batch_Cov = torch.tensor(s_batch_Cov, dtype=torch.float).to(device)
        Cov_output = self.CNN_space(s_batch_Cov)
        output = Cov_output.reshape(self.batch_size, -1)  # 使用 -1 自动计算第二维大小

        # 如果实际特征维度与预期不符，调整输出
        if output.size(1) != self.Global_features:
            print(f"警告: 全局特征维度不匹配，期望 {self.Global_features}，实际 {output.size(1)}")
            # 调整全局特征维度为实际值
            self.Global_features = output.size(1)
            # 可能需要重新初始化混合网络
            self.qmixer = qmixer.QMixer(self.agent_Num, self.Global_features, self.agent_Num * 10,
                                        self.Global_features * 10).to(device)
            self.target_qmixer = qmixer.QMixer(self.agent_Num, self.Global_features, self.agent_Num * 10,
                                               self.Global_features * 10).to(device)
            # 更新参数列表
            self.params = list(self.CNN_space.parameters())
            self.params += list(self.agents.parameters())
            self.params += list(self.qmixer.parameters())
            self.optimizer = torch.optim.RMSprop(params=self.params, lr=self.learning_rate, alpha=0.99, eps=0.00001)

        # 当前联合 Q 值
        CurrValue = torch.zeros((self.batch_size, self.agent_Num)).to(device)
        for agent_idx in range(self.agent_Num):
            Dim_Start = self.Local_Obs * agent_idx
            Dim_End = self.Local_Obs * (agent_idx + 1)
            obs_batch_temp = obs_batch[:, Dim_Start:Dim_End]
            obs_batch_temp = torch.tensor(obs_batch_temp, dtype=torch.float).to(device)
            obs_batch_temp = torch.cat((output, obs_batch_temp), dim=1)
            q_curr_agent = self.agents(obs_batch_temp)
            for i in range(self.batch_size):
                CurrValue[i, agent_idx] = q_curr_agent[i, int(a_batch[i, agent_idx])]

        # 下一个状态的卷积编码
        s_next_batch_Cov = s_next_batch.reshape(self.batch_size, 6, self.row, self.lin)
        s_next_batch_Cov = torch.tensor(s_next_batch_Cov, dtype=torch.float).to(device)
        Cov_output_next = self.CNN_space_target(s_next_batch_Cov)
        output_next = Cov_output_next.reshape(self.batch_size, self.Global_features)

        # 计算下一个时刻的最大 Q 值
        NextValue = torch.zeros((self.batch_size, self.agent_Num)).to(device)
        avail_action_next_batch = torch.tensor(avail_action_next_batch, dtype=torch.float).to(device)
        for agent_idx in range(self.agent_Num):
            Dim_Start = self.Local_Obs * agent_idx
            Dim_End = self.Local_Obs * (agent_idx + 1)
            obs_next_temp = obs_next_batch[:, Dim_Start:Dim_End]
            obs_next_temp = torch.tensor(obs_next_temp, dtype=torch.float).to(device)
            obs_next_temp = torch.cat((output_next, obs_next_temp), dim=1)
            q_next_agent = self.target_agents(obs_next_temp)
            Dim_Start = self.agent_actions * agent_idx
            Dim_End = self.agent_actions * (agent_idx + 1)
            q_next_agent[avail_action_next_batch[:, Dim_Start:Dim_End] == 0.0] = -9999999
            NextValue[:, agent_idx] = torch.max(q_next_agent, dim=1)[0]

        # 混合器输出当前和目标 Q 值
        chosen_action_qvals = self.qmixer(output, CurrValue)
        target_max_qvals = self.target_qmixer(output_next, NextValue)

        r_batch_temp = torch.tensor(r_batch, dtype=torch.float).to(device)
        t_batch_temp = torch.tensor(t_batch, dtype=torch.float).to(device)
        yi = r_batch_temp + self.reward_decay * (1 - t_batch_temp) * target_max_qvals

        # 损失函数及反向传播
        loss_fn = torch.nn.MSELoss()
        loss = loss_fn(chosen_action_qvals, yi)

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.params, 10)
        self.optimizer.step()

        self.learn_step_counter += 1

        # 目标网络更新
        if self.learn_step_counter % self.update_target_network == 0:
            #print("🛠 正在更新目标网络参数")
            self.CNN_space_target.update(self.CNN_space)
            self.target_agents.update(self.agents)
            self.target_qmixer.update(self.qmixer)

        # epsilon 更新
        if self.learn_step_counter % self.batch_size == 0:
            self.INITIAL_EPSILON = max(self.FINAL_EPSILON, self.INITIAL_EPSILON - (
                        self.INITIAL_EPSILON - self.FINAL_EPSILON) / self.batch_size)
            #print("当前 epsilon:", self.INITIAL_EPSILON)

        # # 仅每10次打印一次调试信息
        # if self.learn_step_counter % 10 == 0:
        #     print(f"\n📊 第 {self.learn_step_counter} 次学习")
        #     print("Q_tot 当前值（chosen_action_qvals）:", chosen_action_qvals[:3].detach().cpu().numpy())
        #     print("Q_tot 目标值（yi）:", yi[:3].detach().cpu().numpy())
        #     print("NextValue 示例:", NextValue[:2].detach().cpu().numpy())
        #     print("当前 loss:", loss.item())

        return loss

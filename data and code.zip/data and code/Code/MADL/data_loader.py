# data_loader.py

import numpy as np
import pandas as pd
import math  # 添加math模块
from scipy.spatial.distance import cdist


def load_data_from_csv(task_file, uav_file, worker_file, datacenter_file):
    """
    从CSV文件加载数据并自动计算网格大小

    返回:
    - Data: 字典，包含所有需要的数据
    """

    # 加载CSV文件
    task_df = pd.read_csv(task_file)
    uav_df = pd.read_csv(uav_file)
    worker_df = pd.read_csv(worker_file)
    datacenter_df = pd.read_csv(datacenter_file)

    # ============ 动态计算网格大小 ============
    # 收集所有数据中的坐标
    all_x = []
    all_y = []

    # 收集任务点坐标
    if 'x' in task_df.columns and 'y' in task_df.columns:
        all_x.extend(task_df['x'].tolist())
        all_y.extend(task_df['y'].tolist())

    # 收集无人机坐标
    if 'x' in uav_df.columns and 'y' in uav_df.columns:
        all_x.extend(uav_df['x'].tolist())
        all_y.extend(uav_df['y'].tolist())

    # 收集工人坐标
    if 'x' in worker_df.columns and 'y' in worker_df.columns:
        all_x.extend(worker_df['x'].tolist())
        all_y.extend(worker_df['y'].tolist())

    # 收集数据中心坐标
    if 'x' in datacenter_df.columns and 'y' in datacenter_df.columns:
        all_x.extend(datacenter_df['x'].tolist())
        all_y.extend(datacenter_df['y'].tolist())

    # 计算网格大小
    if all_x and all_y:
        # 找到最大坐标（假设坐标从0或1开始）
        max_x = max(all_x)
        max_y = max(all_y)

        # ⚠️ 修复关键问题：确保转换为整数
        # 方法1：向上取整并加1
        rows = int(math.ceil(max_x)) + 1
        cols = int(math.ceil(max_y)) + 1

        # 或者方法2：直接转换为整数并加1
        # rows = int(max_x) + 1
        # cols = int(max_y) + 1

        print(f"🔍 根据数据自动计算网格大小: {rows} x {cols}")
        print(f"   最大X坐标: {max_x}, 最大Y坐标: {max_y}")
        print(f"   X坐标类型: {type(max_x)}, Y坐标类型: {type(max_y)}")
    else:
        # 如果没有找到坐标，使用默认值
        rows, cols = 30, 30
        print(f"⚠️ 无法计算网格大小，使用默认值: {rows} x {cols}")

    # ============ 继续原来的代码 ============
    # 1. 创建环境网格 Env (3, rows, cols)
    # 通道0: 障碍物 (全部为0，表示可通行)
    # 通道1: 任务点位置
    # 通道2: 数据中心位置
    Env = np.zeros((3, rows, cols))

    # 设置任务点位置（确保坐标转换为整数）
    for _, row in task_df.iterrows():
        # 确保转换为整数
        x = int(float(row['x']))
        y = int(float(row['y']))
        # 确保坐标在网格范围内
        if 0 <= x < rows and 0 <= y < cols:
            Env[1, x, y] = 1  # 任务点

    # 设置数据中心位置
    for _, row in datacenter_df.iterrows():
        x = int(float(row['x']))
        y = int(float(row['y']))
        if 0 <= x < rows and 0 <= y < cols:
            Env[2, x, y] = 1  # 数据中心

    # 2. 创建智能体信息
    uav_count = len(uav_df)
    worker_count = len(worker_df)
    agent_num = uav_count + worker_count

    # Agent_Sign: 1=工人, 3=无人机
    Agent_Sign = np.zeros(agent_num, dtype=int)
    Agent_Sign[:worker_count] = 1  # 前worker_count个是工人
    Agent_Sign[worker_count:] = 3  # 后面的是无人机

    # Agent_Loc: (agent_num, rows, cols)
    Agent_Loc = np.zeros((agent_num, rows, cols))

    # 工人位置
    for i, (_, row) in enumerate(worker_df.iterrows()):
        x = int(float(row['x']))
        y = int(float(row['y']))
        if 0 <= x < rows and 0 <= y < cols:
            Agent_Loc[i, x, y] = 1

    # 无人机位置
    for i, (_, row) in enumerate(uav_df.iterrows()):
        idx = worker_count + i
        x = int(float(row['x']))
        y = int(float(row['y']))
        if 0 <= x < rows and 0 <= y < cols:
            Agent_Loc[idx, x, y] = 1

    # Action_Dim: (agent_num, 1) - 移动半径
    Action_Dim = np.zeros((agent_num, 1))

    # 工人移动半径
    for i, (_, row) in enumerate(worker_df.iterrows()):
        Action_Dim[i, 0] = float(row['workerRge'])

    # 无人机移动半径
    for i, (_, row) in enumerate(uav_df.iterrows()):
        idx = worker_count + i
        Action_Dim[idx, 0] = float(row['uavRge'])

    # Memory: (agent_num,) - 当前存储数据量
    Memory = np.zeros(agent_num)

    # 工人初始内存为0
    # 无人机当前存储数据量
    for i, (_, row) in enumerate(uav_df.iterrows()):
        idx = worker_count + i
        Memory[idx] = float(row['Currentm'])

    # DataConsum: (agent_num,) - 完成任务所需数据量
    DataConsum = np.zeros(agent_num)

    # 工人完成任务所需数据量（设为平均任务消耗）
    avg_task_cost = task_df['T_costData'].mean() if 'T_costData' in task_df.columns else 3
    DataConsum[:worker_count] = float(avg_task_cost)

    # 无人机完成任务所需数据量
    for i in range(uav_count):
        idx = worker_count + i
        DataConsum[idx] = float(avg_task_cost)

    # Agent_Online: (agent_num, 2) - 上线和下线时间
    Agent_Online = np.zeros((agent_num, 2), dtype=int)

    # 工人上下线时间
    for i, (_, row) in enumerate(worker_df.iterrows()):
        Agent_Online[i, 0] = int(row['W_uptime'])
        Agent_Online[i, 1] = int(row['W_downtime'])

    # 无人机上下线时间
    for i, (_, row) in enumerate(uav_df.iterrows()):
        idx = worker_count + i
        Agent_Online[idx, 0] = int(row['U_uptime'])
        Agent_Online[idx, 1] = int(row['U_downtime'])

    # 无人机最大存储容量（用于卸载判断）
    UAV_Fullm = np.zeros(uav_count)
    for i, (_, row) in enumerate(uav_df.iterrows()):
        UAV_Fullm[i] = float(row['Fullm'])

    # 任务消耗数据量字典（用于任务完成时消耗）
    task_cost_dict = {}
    for _, row in task_df.iterrows():
        x = int(float(row['x']))
        y = int(float(row['y']))
        cost = float(row['T_costData'])
        task_cost_dict[(x, y)] = cost

    # 数据中心位置列表
    datacenter_positions = []
    for _, row in datacenter_df.iterrows():
        x = int(float(row['x']))
        y = int(float(row['y']))
        datacenter_positions.append((x, y))

    # 返回所有数据
    Data = {
        'Env': Env,
        'Agent_Sign': Agent_Sign,
        'Agent_Loc': Agent_Loc,
        'Action_Dim': Action_Dim,
        'Memory': Memory,
        'DataConsum': DataConsum,
        'Agent_Online': Agent_Online,
        'UAV_Fullm': UAV_Fullm,
        'task_cost_dict': task_cost_dict,
        'datacenter_positions': datacenter_positions,
        'uav_count': uav_count,
        'worker_count': worker_count,
        'grid_size': (rows, cols)  # 添加网格大小信息
    }

    return Data


def find_nearest_datacenter(current_pos, datacenter_positions):
    """
    找到离当前位置最近的数据中心

    参数:
    - current_pos: (x, y) 当前位置
    - datacenter_positions: 数据中心位置列表

    返回:
    - nearest_dc: (x, y) 最近的数据中心位置
    - distance: 到最近数据中心的距离
    """
    if not datacenter_positions:
        return None, float('inf')

    # 计算到所有数据中心的距离
    distances = []
    for dc_pos in datacenter_positions:
        dist = np.sqrt((current_pos[0] - dc_pos[0]) ** 2 +
                       (current_pos[1] - dc_pos[1]) ** 2)
        distances.append(dist)

    # 找到最近的数据中心
    min_idx = np.argmin(distances)
    return datacenter_positions[min_idx], distances[min_idx]